-- Create role enum type (drop first if it exists)
DROP TYPE IF EXISTS public.user_role CASCADE;
CREATE TYPE public.user_role AS ENUM ('admin', 'user');

-- Add organization_id column to profiles table
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS organization_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE;

-- Create a new temporary role column with the enum type
ALTER TABLE public.profiles ADD COLUMN temp_role public.user_role DEFAULT 'user'::public.user_role;

-- Copy data from the old role column to the new one, handling the conversion safely
UPDATE public.profiles 
SET temp_role = CASE 
  WHEN role = 'admin' THEN 'admin'::public.user_role
  ELSE 'user'::public.user_role
END;

-- Drop the old role column and rename the new one
ALTER TABLE public.profiles DROP COLUMN role;
ALTER TABLE public.profiles RENAME COLUMN temp_role TO role;
ALTER TABLE public.profiles ALTER COLUMN role SET NOT NULL;

-- Update the handle_new_user function to assign users to a default organization
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  default_org_id UUID;
BEGIN
  -- Try to find an existing organization or create a default one
  SELECT id INTO default_org_id 
  FROM public.organizations 
  WHERE name = 'Default Organization' 
  LIMIT 1;
  
  -- If no default organization exists, create one
  IF default_org_id IS NULL THEN
    INSERT INTO public.organizations (name, owner_id)
    VALUES ('Default Organization', NEW.id)
    RETURNING id INTO default_org_id;
  END IF;

  -- Insert the profile with organization assignment
  INSERT INTO public.profiles (user_id, first_name, last_name, phone_number, organization_id, role)
  VALUES (
    NEW.id,
    NEW.raw_user_meta_data ->> 'first_name',
    NEW.raw_user_meta_data ->> 'last_name',
    NEW.raw_user_meta_data ->> 'phone_number',
    default_org_id,
    CASE 
      WHEN NEW.id = (SELECT owner_id FROM public.organizations WHERE id = default_org_id)
      THEN 'admin'::public.user_role
      ELSE 'user'::public.user_role
    END
  );
  
  RETURN NEW;
END;
$$;