-- Add invite token fields to app_users table for manual user additions
ALTER TABLE public.app_users 
ADD COLUMN invite_token TEXT UNIQUE,
ADD COLUMN invite_expires_at TIMESTAMP WITH TIME ZONE;

-- Create index for faster token lookups
CREATE INDEX idx_app_users_invite_token ON public.app_users(invite_token) WHERE invite_token IS NOT NULL;

-- Create function to generate unique invite tokens
CREATE OR REPLACE FUNCTION public.generate_invite_token()
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    token TEXT;
    exists_check INTEGER;
BEGIN
    -- Generate a random token until we find a unique one
    LOOP
        token := encode(gen_random_bytes(32), 'base64url');
        SELECT COUNT(*) INTO exists_check FROM public.app_users WHERE invite_token = token;
        EXIT WHEN exists_check = 0;
    END LOOP;
    
    RETURN token;
END;
$$;