-- Enhance the subscriptions table to support storage add-ons and usage tracking
ALTER TABLE public.subscriptions 
ADD COLUMN IF NOT EXISTS storage_limit_gb INTEGER DEFAULT 20,
ADD COLUMN IF NOT EXISTS storage_used_gb DECIMAL(10,2) DEFAULT 0,
ADD COLUMN IF NOT EXISTS query_limit INTEGER DEFAULT 1500,
ADD COLUMN IF NOT EXISTS queries_used INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS queries_reset_at TIMESTAMP WITH TIME ZONE DEFAULT date_trunc('month', now()) + INTERVAL '1 month',
ADD COLUMN IF NOT EXISTS stripe_price_id TEXT,
ADD COLUMN IF NOT EXISTS additional_storage_gb INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS additional_storage_subscription_ids TEXT[];

-- Create subscription_add_ons table to track storage and other add-ons
CREATE TABLE IF NOT EXISTS public.subscription_add_ons (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  subscription_id UUID NOT NULL,
  stripe_subscription_id TEXT NOT NULL,
  add_on_type TEXT NOT NULL CHECK (add_on_type IN ('storage', 'queries')),
  quantity INTEGER NOT NULL DEFAULT 1,
  stripe_price_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  current_period_start TIMESTAMP WITH TIME ZONE,
  current_period_end TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, stripe_subscription_id)
);

-- Enable RLS on subscription_add_ons
ALTER TABLE public.subscription_add_ons ENABLE ROW LEVEL SECURITY;

-- Create policies for subscription_add_ons
CREATE POLICY "Users can view their own subscription add-ons" 
ON public.subscription_add_ons 
FOR SELECT 
USING (user_id = auth.uid());

CREATE POLICY "Edge functions can manage subscription add-ons" 
ON public.subscription_add_ons 
FOR ALL 
USING (auth.role() = 'service_role'::text);

-- Create function to reset monthly query count
CREATE OR REPLACE FUNCTION public.reset_monthly_queries()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.subscriptions 
  SET queries_used = 0,
      queries_reset_at = date_trunc('month', now()) + INTERVAL '1 month'
  WHERE queries_reset_at <= now();
END;
$$;

-- Create function to check subscription access with grace period
CREATE OR REPLACE FUNCTION public.has_active_subscription_access(p_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  subscription_record RECORD;
BEGIN
  SELECT status, current_period_end 
  INTO subscription_record
  FROM public.subscriptions 
  WHERE user_id = p_user_id;
  
  -- If no subscription record, no access
  IF NOT FOUND THEN
    RETURN false;
  END IF;
  
  -- If status is active, trialing, or past_due with grace period, allow access
  RETURN (
    subscription_record.status IN ('active', 'trialing') OR 
    (subscription_record.status IN ('past_due', 'canceled') AND 
     subscription_record.current_period_end > now())
  );
END;
$$;

-- Create function to calculate total storage limit including add-ons
CREATE OR REPLACE FUNCTION public.get_total_storage_limit(p_user_id uuid)
RETURNS integer
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  base_limit integer := 20;
  additional_storage integer := 0;
BEGIN
  -- Get base storage limit from subscription
  SELECT storage_limit_gb INTO base_limit
  FROM public.subscriptions 
  WHERE user_id = p_user_id;
  
  -- Get additional storage from add-ons
  SELECT COALESCE(SUM(quantity * 10), 0) INTO additional_storage
  FROM public.subscription_add_ons 
  WHERE user_id = p_user_id 
    AND add_on_type = 'storage' 
    AND status = 'active';
  
  RETURN COALESCE(base_limit, 20) + additional_storage;
END;
$$;

-- Create triggers for updating timestamps
CREATE TRIGGER update_subscription_add_ons_updated_at
BEFORE UPDATE ON public.subscription_add_ons
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();