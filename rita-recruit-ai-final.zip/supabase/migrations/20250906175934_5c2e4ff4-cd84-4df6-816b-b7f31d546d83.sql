-- Create waitlist signups table
CREATE TABLE public.waitlist_signups (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  email TEXT NOT NULL,
  company_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.waitlist_signups ENABLE ROW LEVEL SECURITY;

-- Create policy to allow anyone to insert waitlist signups (public form)
CREATE POLICY "Anyone can submit waitlist signup" 
ON public.waitlist_signups 
FOR INSERT 
WITH CHECK (true);

-- Create policy for admins to view all waitlist signups
CREATE POLICY "Admins can view all waitlist signups" 
ON public.waitlist_signups 
FOR SELECT 
USING (is_admin());

-- Add unique constraint on email to prevent duplicates
ALTER TABLE public.waitlist_signups 
ADD CONSTRAINT unique_waitlist_email UNIQUE (email);

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_waitlist_signups_updated_at
BEFORE UPDATE ON public.waitlist_signups
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();