-- Add columns to subscriptions table to support introductory pricing
ALTER TABLE public.subscriptions 
ADD COLUMN IF NOT EXISTS intro_period_active boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS intro_cycles_remaining integer DEFAULT 0,
ADD COLUMN IF NOT EXISTS standard_price_id text,
ADD COLUMN IF NOT EXISTS intro_price_id text,
ADD COLUMN IF NOT EXISTS intro_end_date timestamp with time zone;