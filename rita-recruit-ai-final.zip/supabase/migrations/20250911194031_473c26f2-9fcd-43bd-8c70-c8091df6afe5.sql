-- Create role enum type
CREATE TYPE public.user_role AS ENUM ('admin', 'user');

-- Add organization_id column to profiles table
ALTER TABLE public.profiles 
ADD COLUMN organization_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE;

-- Update role column to use enum (handle type conversion properly)
UPDATE public.profiles SET role = 'user' WHERE role IS NULL;
ALTER TABLE public.profiles ALTER COLUMN role DROP DEFAULT;
ALTER TABLE public.profiles ALTER COLUMN role TYPE public.user_role USING 
  CASE 
    WHEN role::text = 'admin' THEN 'admin'::public.user_role
    ELSE 'user'::public.user_role 
  END;
ALTER TABLE public.profiles ALTER COLUMN role SET DEFAULT 'user'::public.user_role;
ALTER TABLE public.profiles ALTER COLUMN role SET NOT NULL;

-- Drop existing RLS policies on profiles
DROP POLICY IF EXISTS "Users can create their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can view their own profile" ON public.profiles;

-- Create new RLS policies for profiles (organization-based)
CREATE POLICY "Users can create their own profile"
ON public.profiles
FOR INSERT
WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can view profiles in their organization"
ON public.profiles
FOR SELECT
USING (
  organization_id IN (
    SELECT organization_id 
    FROM public.profiles 
    WHERE user_id = auth.uid()
  )
);

CREATE POLICY "Users can update their own profile"
ON public.profiles
FOR UPDATE
USING (user_id = auth.uid());

CREATE POLICY "Organization admins can update profiles in their org"
ON public.profiles
FOR UPDATE
USING (
  organization_id IN (
    SELECT organization_id 
    FROM public.profiles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
  )
);

-- Update organizations RLS policies
DROP POLICY IF EXISTS "Users can view their own organization" ON public.organizations;
DROP POLICY IF EXISTS "Users can update their own organization" ON public.organizations;
DROP POLICY IF EXISTS "Users can insert their own organization" ON public.organizations;

CREATE POLICY "Organization members can view their organization"
ON public.organizations
FOR SELECT
USING (
  id IN (
    SELECT organization_id 
    FROM public.profiles 
    WHERE user_id = auth.uid()
  )
);

CREATE POLICY "Organization owners can update their organization"
ON public.organizations
FOR UPDATE
USING (owner_id = auth.uid());

CREATE POLICY "Users can create organizations"
ON public.organizations
FOR INSERT
WITH CHECK (owner_id = auth.uid());

-- Update app_users RLS policies for organization-based admin access
DROP POLICY IF EXISTS "Users can view their invited users or admins see all" ON public.app_users;
DROP POLICY IF EXISTS "Users can update their invited users or admins update all" ON public.app_users;
DROP POLICY IF EXISTS "Users can delete their invited users or admins delete all" ON public.app_users;
DROP POLICY IF EXISTS "Users can create app users" ON public.app_users;

CREATE POLICY "Organization admins can view users in their org"
ON public.app_users
FOR SELECT
USING (
  invited_by IN (
    SELECT user_id 
    FROM public.profiles 
    WHERE organization_id = (
      SELECT organization_id 
      FROM public.profiles 
      WHERE user_id = auth.uid() 
      AND role = 'admin'
    )
  )
  OR invited_by = auth.uid()
);

CREATE POLICY "Organization admins can invite users to their org"
ON public.app_users
FOR INSERT
WITH CHECK (
  invited_by = auth.uid() 
  AND EXISTS (
    SELECT 1 
    FROM public.profiles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
  )
);

CREATE POLICY "Organization admins can update users in their org"
ON public.app_users
FOR UPDATE
USING (
  invited_by IN (
    SELECT user_id 
    FROM public.profiles 
    WHERE organization_id = (
      SELECT organization_id 
      FROM public.profiles 
      WHERE user_id = auth.uid() 
      AND role = 'admin'
    )
  )
  OR invited_by = auth.uid()
);

CREATE POLICY "Organization admins can delete users in their org"
ON public.app_users
FOR DELETE
USING (
  invited_by IN (
    SELECT user_id 
    FROM public.profiles 
    WHERE organization_id = (
      SELECT organization_id 
      FROM public.profiles 
      WHERE user_id = auth.uid() 
      AND role = 'admin'
    )
  )
  OR invited_by = auth.uid()
);

-- Update document-related tables to use organization-based access
-- Update document_folders RLS
DROP POLICY IF EXISTS "Users can view their own folders" ON public.document_folders;
DROP POLICY IF EXISTS "Users can create their own folders" ON public.document_folders;
DROP POLICY IF EXISTS "Users can update their own folders" ON public.document_folders;
DROP POLICY IF EXISTS "Users can delete their own folders" ON public.document_folders;

CREATE POLICY "Users can view folders in their organization"
ON public.document_folders
FOR SELECT
USING (
  user_id IN (
    SELECT user_id 
    FROM public.profiles 
    WHERE organization_id = (
      SELECT organization_id 
      FROM public.profiles 
      WHERE user_id = auth.uid()
    )
  )
);

CREATE POLICY "Users can create folders in their organization"
ON public.document_folders
FOR INSERT
WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update their own folders"
ON public.document_folders
FOR UPDATE
USING (user_id = auth.uid());

CREATE POLICY "Users can delete their own folders"
ON public.document_folders
FOR DELETE
USING (user_id = auth.uid());

-- Update document_files RLS
DROP POLICY IF EXISTS "Users can view their own files" ON public.document_files;
DROP POLICY IF EXISTS "Users can create their own files" ON public.document_files;
DROP POLICY IF EXISTS "Users can update their own files" ON public.document_files;
DROP POLICY IF EXISTS "Users can delete their own files" ON public.document_files;

CREATE POLICY "Users can view files in their organization"
ON public.document_files
FOR SELECT
USING (
  user_id IN (
    SELECT user_id 
    FROM public.profiles 
    WHERE organization_id = (
      SELECT organization_id 
      FROM public.profiles 
      WHERE user_id = auth.uid()
    )
  )
);

CREATE POLICY "Users can create their own files"
ON public.document_files
FOR INSERT
WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update their own files"
ON public.document_files
FOR UPDATE
USING (user_id = auth.uid());

CREATE POLICY "Users can delete their own files"
ON public.document_files
FOR DELETE
USING (user_id = auth.uid());

-- Update document_content RLS
DROP POLICY IF EXISTS "Users can view their own document content" ON public.document_content;
DROP POLICY IF EXISTS "Users can create their own document content" ON public.document_content;
DROP POLICY IF EXISTS "Users can update their own document content" ON public.document_content;

CREATE POLICY "Users can view document content in their organization"
ON public.document_content
FOR SELECT
USING (
  file_id IN (
    SELECT df.id 
    FROM public.document_files df
    JOIN public.profiles p ON df.user_id = p.user_id
    WHERE p.organization_id = (
      SELECT organization_id 
      FROM public.profiles 
      WHERE user_id = auth.uid()
    )
  )
);

CREATE POLICY "Users can create document content for their files"
ON public.document_content
FOR INSERT
WITH CHECK (
  file_id IN (
    SELECT id 
    FROM public.document_files 
    WHERE user_id = auth.uid()
  )
);

CREATE POLICY "Users can update document content for their files"
ON public.document_content
FOR UPDATE
USING (
  file_id IN (
    SELECT id 
    FROM public.document_files 
    WHERE user_id = auth.uid()
  )
);

-- Update the handle_new_user function to assign users to a default organization
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  default_org_id UUID;
BEGIN
  -- Try to find an existing organization or create a default one
  SELECT id INTO default_org_id 
  FROM public.organizations 
  WHERE name = 'Default Organization' 
  LIMIT 1;
  
  -- If no default organization exists, create one
  IF default_org_id IS NULL THEN
    INSERT INTO public.organizations (name, owner_id)
    VALUES ('Default Organization', NEW.id)
    RETURNING id INTO default_org_id;
  END IF;

  -- Insert the profile with organization assignment
  INSERT INTO public.profiles (user_id, first_name, last_name, phone_number, organization_id, role)
  VALUES (
    NEW.id,
    NEW.raw_user_meta_data ->> 'first_name',
    NEW.raw_user_meta_data ->> 'last_name',
    NEW.raw_user_meta_data ->> 'phone_number',
    default_org_id,
    CASE 
      WHEN NEW.id = (SELECT owner_id FROM public.organizations WHERE id = default_org_id)
      THEN 'admin'::public.user_role
      ELSE 'user'::public.user_role
    END
  );
  
  RETURN NEW;
END;
$$;