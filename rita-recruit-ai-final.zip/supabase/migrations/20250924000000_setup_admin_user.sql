-- Setup Admin User and Master Organization
-- This migration creates the master admin account and DriveLine Solutions organization

-- Create DriveLine Solutions organization with unlimited plan
INSERT INTO organizations (
  id,
  name,
  subscription_status,
  plan_type,
  storage_limit_gb,
  query_limit,
  created_at,
  updated_at
) VALUES (
  gen_random_uuid(),
  'DriveLine Solutions',
  'active',
  'unlimited',
  999999, -- Unlimited storage
  999999, -- Unlimited queries
  now(),
  now()
) ON CONFLICT DO NOTHING;

-- Create admin role if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'user_role') THEN
    CREATE TYPE user_role AS ENUM ('admin', 'owner', 'member');
  END IF;
  
  -- Add admin to existing enum if it doesn't exist
  IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'admin' AND enumtypid = (SELECT oid FROM pg_type WHERE typname = 'user_role')) THEN
    ALTER TYPE user_role ADD VALUE 'admin';
  END IF;
END
$$;

-- Function to create admin user profile after auth user is created
CREATE OR REPLACE FUNCTION create_admin_profile()
RETURNS TRIGGER AS $$
DECLARE
  org_id uuid;
BEGIN
  -- Only create admin profile for rebecca@drivelinesolutions.net
  IF NEW.email = 'rebecca@drivelinesolutions.net' THEN
    -- Get DriveLine Solutions organization ID
    SELECT id INTO org_id FROM organizations WHERE name = 'DriveLine Solutions' LIMIT 1;
    
    -- Create admin profile
    INSERT INTO profiles (
      id,
      email,
      full_name,
      organization_id,
      role,
      created_at,
      updated_at
    ) VALUES (
      NEW.id,
      NEW.email,
      'Rebecca - Admin',
      org_id,
      'admin',
      now(),
      now()
    );
    
    -- Update organization owner
    UPDATE organizations 
    SET owner_id = NEW.id 
    WHERE id = org_id;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for admin user creation
DROP TRIGGER IF EXISTS create_admin_profile_trigger ON auth.users;
CREATE TRIGGER create_admin_profile_trigger
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION create_admin_profile();

-- Update RLS policies to allow admin access
CREATE POLICY "Admins can view all organizations" ON organizations
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Admins can update all organizations" ON organizations
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Admins can view all profiles" ON profiles
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid() 
      AND p.role = 'admin'
    )
  );

CREATE POLICY "Admins can update all profiles" ON profiles
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid() 
      AND p.role = 'admin'
    )
  );

-- Create admin dashboard access function
CREATE OR REPLACE FUNCTION is_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM profiles 
    WHERE id = auth.uid() 
    AND role = 'admin'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant admin unlimited access to all features
CREATE OR REPLACE FUNCTION get_organization_limits(org_id uuid)
RETURNS TABLE (
  storage_limit_gb integer,
  query_limit integer,
  storage_used_gb integer,
  queries_used integer
) AS $$
BEGIN
  -- Check if user is admin
  IF is_admin() THEN
    RETURN QUERY SELECT 
      999999 as storage_limit_gb,
      999999 as query_limit,
      0 as storage_used_gb,
      0 as queries_used;
  ELSE
    RETURN QUERY SELECT 
      o.storage_limit_gb,
      o.query_limit,
      COALESCE(o.storage_used_gb, 0) as storage_used_gb,
      COALESCE(o.queries_used, 0) as queries_used
    FROM organizations o
    WHERE o.id = org_id;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Add admin route protection
CREATE OR REPLACE FUNCTION can_access_admin_dashboard()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM profiles 
    WHERE id = auth.uid() 
    AND role = 'admin'
    AND email = 'rebecca@drivelinesolutions.net'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create admin activity log table
CREATE TABLE IF NOT EXISTS admin_activity_log (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  admin_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  action text NOT NULL,
  target_type text, -- 'organization', 'user', 'subscription', etc.
  target_id uuid,
  details jsonb,
  created_at timestamp with time zone DEFAULT now()
);

-- Enable RLS on admin activity log
ALTER TABLE admin_activity_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view activity log" ON admin_activity_log
  FOR SELECT USING (is_admin());

CREATE POLICY "Admins can insert activity log" ON admin_activity_log
  FOR INSERT WITH CHECK (is_admin());

-- Function to log admin activities
CREATE OR REPLACE FUNCTION log_admin_activity(
  action_text text,
  target_type_text text DEFAULT NULL,
  target_id_param uuid DEFAULT NULL,
  details_param jsonb DEFAULT NULL
)
RETURNS void AS $$
BEGIN
  IF is_admin() THEN
    INSERT INTO admin_activity_log (admin_id, action, target_type, target_id, details)
    VALUES (auth.uid(), action_text, target_type_text, target_id_param, details_param);
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
