-- Create demo_responses table for predefined Q&A pairs
CREATE TABLE public.demo_responses (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  question_text TEXT NOT NULL,
  answer_text TEXT NOT NULL,
  carrier_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.demo_responses ENABLE ROW LEVEL SECURITY;

-- Create policy for public read access (demo data should be accessible to all)
CREATE POLICY "Demo responses are viewable by everyone" 
ON public.demo_responses 
FOR SELECT 
USING (true);

-- Insert demo Q&A pairs
INSERT INTO public.demo_responses (question_text, answer_text, carrier_name) VALUES
(
  'Does Blue Ridge Logistics hire within 75 miles of Tulsa OK for regional reefer job BR-2317?',
  'Yes! Blue Ridge Logistics is actively hiring for position BR-2317 within a 75-mile radius of Tulsa, OK. This regional reefer position offers:

• Home every weekend
• $1,850-$2,100/week average
• 2+ years experience required
• Clean MVR (no major violations in 3 years)
• Dedicated reefer routes through TX, OK, AR

To apply, drivers can call our recruiting hotline at (555) 247-8900 or submit an application through our driver portal. We''re scheduling phone interviews this week!',
  'Blue Ridge Logistics'
),
(
  'What is IronSparrow Freight''s DUI and accident policy?',
  'IronSparrow Freight maintains strict safety standards:

**DUI Policy:**
• No DUI/DWI convictions in the past 7 years
• Any alcohol-related violations result in immediate disqualification
• Random DOT drug/alcohol testing required

**Accident Policy:**  
• No preventable accidents in the past 3 years
• Maximum of 1 non-preventable accident in 24 months
• All accidents require detailed MVR review
• CSA scores must be below 65% in all categories

**Additional Requirements:**
• Clean background check
• Valid medical card
• Minimum 2 years verifiable experience

Exceptions may be considered on a case-by-case basis for drivers with 5+ years experience and stellar safety records.',
  'IronSparrow Freight'
),
(
  'Can you check if Johnson Trucking has any local delivery positions in Atlanta?',
  'Great news! Johnson Trucking currently has several local delivery positions available in the Atlanta metro area:

**Position: Local Delivery Driver - ATL-LD-2024**
• Home daily, weekends off
• $72,000-$85,000 annual salary
• Routes primarily in Fulton, DeKalb, and Gwinnett counties
• Straight truck and dock-to-dock deliveries

**Requirements:**
• Class A or B CDL with clean record
• 1+ years local/regional experience preferred
• Ability to lift up to 75 lbs
• Customer service skills essential

**Benefits Package:**
• Medical, dental, vision insurance
• 401(k) with 4% company match  
• 3 weeks PTO first year
• $500 safety bonus quarterly

Applications being processed within 48 hours. Contact Atlanta terminal at (404) 555-0199 or apply online at johnsontruck.com/careers',
  'Johnson Trucking'
),
(
  'What are the benefits and pay for Riverbend Carriers'' OTR positions?',
  'Riverbend Carriers offers competitive compensation and comprehensive benefits for OTR drivers:

**Pay Structure:**
• $0.68-$0.78 per mile (based on experience)
• Average $75,000-$95,000 annually
• Weekly direct deposit guaranteed
• $500 sign-on bonus after 90 days

**Benefits Package:**
• Full medical, dental, vision (company pays 80%)
• $50,000 life insurance policy
• 401(k) with 6% company match
• 2 weeks PTO first year, 3 weeks after 2 years

**Additional Perks:**  
• Rider/pet policy available
• Fuel cards with fleet discounts
• 24/7 breakdown assistance
• Modern Kenworth and Peterbilt fleet (avg 2 years old)
• ELD with integrated GPS and messaging

**Time Off:**
• Home every 2-3 weeks for 34-hour reset
• Flexible scheduling for holidays
• Family emergency time off policy

Ready to join our team? Call (800) 555-RIVER or visit riverbendcarriers.com/drive',
  'Riverbend Carriers'
);

-- Create function to update timestamps
CREATE TRIGGER update_demo_responses_updated_at
BEFORE UPDATE ON public.demo_responses
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();