-- Create document_content table to store extracted text from uploaded files
CREATE TABLE public.document_content (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  file_id UUID NOT NULL REFERENCES public.document_files(id) ON DELETE CASCADE,
  content_text TEXT NOT NULL,
  content_summary TEXT,
  extracted_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  processing_status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on document_content
ALTER TABLE public.document_content ENABLE ROW LEVEL SECURITY;

-- Create policies for document_content (users can only access content from their own files)
CREATE POLICY "Users can view their own document content" 
ON public.document_content 
FOR SELECT 
USING (
  file_id IN (
    SELECT id FROM public.document_files 
    WHERE user_id = auth.uid()
  )
);

CREATE POLICY "Users can create their own document content" 
ON public.document_content 
FOR INSERT 
WITH CHECK (
  file_id IN (
    SELECT id FROM public.document_files 
    WHERE user_id = auth.uid()
  )
);

CREATE POLICY "Users can update their own document content" 
ON public.document_content 
FOR UPDATE 
USING (
  file_id IN (
    SELECT id FROM public.document_files 
    WHERE user_id = auth.uid()
  )
);

-- Create index for better search performance
CREATE INDEX idx_document_content_file_id ON public.document_content(file_id);
CREATE INDEX idx_document_content_text_search ON public.document_content USING gin(to_tsvector('english', content_text));

-- Add trigger for automatic timestamp updates
CREATE TRIGGER update_document_content_updated_at
BEFORE UPDATE ON public.document_content
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Add processing_status column to document_files to track extraction progress
ALTER TABLE public.document_files 
ADD COLUMN processing_status TEXT DEFAULT 'pending',
ADD COLUMN has_content BOOLEAN DEFAULT false;

-- Create function to search document content for a user
CREATE OR REPLACE FUNCTION public.search_user_documents(
  p_user_id UUID,
  p_search_query TEXT,
  p_limit INTEGER DEFAULT 5
)
RETURNS TABLE(
  file_id UUID,
  file_name TEXT,
  folder_name TEXT,
  category_name TEXT,
  content_snippet TEXT,
  relevance_score REAL
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    df.id as file_id,
    df.file_name,
    dfo.name as folder_name,
    dc.name as category_name,
    LEFT(dct.content_text, 500) as content_snippet,
    ts_rank(to_tsvector('english', dct.content_text), plainto_tsquery('english', p_search_query)) as relevance_score
  FROM public.document_content dct
  JOIN public.document_files df ON dct.file_id = df.id
  JOIN public.document_folders dfo ON df.folder_id = dfo.id
  JOIN public.document_categories dc ON dfo.category_id = dc.id
  WHERE df.user_id = p_user_id 
    AND dct.processing_status = 'completed'
    AND to_tsvector('english', dct.content_text) @@ plainto_tsquery('english', p_search_query)
  ORDER BY relevance_score DESC
  LIMIT p_limit;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;