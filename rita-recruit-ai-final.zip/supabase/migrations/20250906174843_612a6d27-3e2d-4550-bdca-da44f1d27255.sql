-- Phase 1: Database Schema Extensions (Simplified)

-- Add is_demo flag to organizations table
ALTER TABLE public.organizations 
ADD COLUMN is_demo BOOLEAN NOT NULL DEFAULT false;

-- Add new columns to document_files table
ALTER TABLE public.document_files 
ADD COLUMN organization_id UUID,
ADD COLUMN source TEXT NOT NULL DEFAULT 'uploaded',
ADD COLUMN ttl_expires_at TIMESTAMP WITH TIME ZONE;

-- Add constraint for source column
ALTER TABLE public.document_files 
ADD CONSTRAINT document_files_source_check 
CHECK (source IN ('uploaded', 'seed', 'demo_cache'));

-- Create demo organization
INSERT INTO public.organizations (id, name, owner_id, is_demo, monthly_query_cap)
VALUES (
  '00000000-0000-0000-0000-000000000000'::uuid,
  'Demo Organization',
  NULL,
  true,
  999999
);

-- Create demo folder using existing "Recruiting Practices" category
DO $$
DECLARE
    recruiter_training_category_id UUID;
    demo_org_id UUID := '00000000-0000-0000-0000-000000000000'::uuid;
BEGIN
    -- Get the recruiting practices category ID 
    SELECT id INTO recruiter_training_category_id 
    FROM public.document_categories 
    WHERE name = 'Recruiting Practices'
    LIMIT 1;

    -- Create demo folder
    INSERT INTO public.document_folders (id, name, description, category_id, user_id, is_hidden, openai_instructions)
    VALUES (
      '11111111-1111-1111-1111-111111111111'::uuid,
      'Carrier Information & Job Details',
      'Demo seed data for carrier policies and job information',
      recruiter_training_category_id,
      NULL, -- No specific user for demo org
      false,
      'Use this information to answer questions about carrier policies, job requirements, and hiring criteria.'
    );
END $$;

-- Update RLS policies to handle demo organization
-- Allow access to demo organization documents for everyone
CREATE POLICY "Demo organization documents are viewable by everyone" 
ON public.document_files 
FOR SELECT 
USING (organization_id = '00000000-0000-0000-0000-000000000000'::uuid);

CREATE POLICY "Demo organization folders are viewable by everyone" 
ON public.document_folders 
FOR SELECT 
USING (user_id IS NULL);

-- Update search function to handle organization filtering
CREATE OR REPLACE FUNCTION public.search_demo_documents(p_search_query text, p_limit integer DEFAULT 5)
RETURNS TABLE(file_id uuid, file_name text, folder_name text, category_name text, content_snippet text, relevance_score real)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $function$
BEGIN
  RETURN QUERY
  SELECT 
    df.id as file_id,
    df.file_name,
    dfo.name as folder_name,
    dc.name as category_name,
    LEFT(dct.content_text, 500) as content_snippet,
    ts_rank(to_tsvector('english', dct.content_text), plainto_tsquery('english', p_search_query)) as relevance_score
  FROM public.document_content dct
  JOIN public.document_files df ON dct.file_id = df.id
  JOIN public.document_folders dfo ON df.folder_id = dfo.id
  JOIN public.document_categories dc ON dfo.category_id = dc.id
  WHERE df.organization_id = '00000000-0000-0000-0000-000000000000'::uuid
    AND df.source = 'seed'
    AND dct.processing_status = 'completed'
    AND to_tsvector('english', dct.content_text) @@ plainto_tsquery('english', p_search_query)
  ORDER BY relevance_score DESC
  LIMIT p_limit;
END;
$function$;