-- Phase 1: Database Schema Extensions (Minimal)

-- Add is_demo flag to organizations table
ALTER TABLE public.organizations 
ADD COLUMN is_demo BOOLEAN NOT NULL DEFAULT false;

-- Add new columns to document_files table  
ALTER TABLE public.document_files 
ADD COLUMN organization_id UUID,
ADD COLUMN source TEXT NOT NULL DEFAULT 'uploaded',
ADD COLUMN ttl_expires_at TIMESTAMP WITH TIME ZONE;

-- Add constraint for source column
ALTER TABLE public.document_files 
ADD CONSTRAINT document_files_source_check 
CHECK (source IN ('uploaded', 'seed', 'demo_cache'));

-- Create demo organization
INSERT INTO public.organizations (id, name, owner_id, is_demo, monthly_query_cap)
VALUES (
  '00000000-0000-0000-0000-000000000000'::uuid,
  'Demo Organization',
  NULL,
  true,
  999999
);

-- Update search function to handle demo document filtering
CREATE OR REPLACE FUNCTION public.search_demo_documents(p_search_query text, p_limit integer DEFAULT 5)
RETURNS TABLE(file_id uuid, file_name text, folder_name text, category_name text, content_snippet text, relevance_score real)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $function$
BEGIN
  RETURN QUERY
  SELECT 
    df.id as file_id,
    df.file_name,
    dfo.name as folder_name,
    dc.name as category_name,
    LEFT(dct.content_text, 500) as content_snippet,
    ts_rank(to_tsvector('english', dct.content_text), plainto_tsquery('english', p_search_query)) as relevance_score
  FROM public.document_content dct
  JOIN public.document_files df ON dct.file_id = df.id
  JOIN public.document_folders dfo ON df.folder_id = dfo.id
  JOIN public.document_categories dc ON dfo.category_id = dc.id
  WHERE df.organization_id = '00000000-0000-0000-0000-000000000000'::uuid
    AND df.source = 'seed'
    AND dct.processing_status = 'completed'
    AND to_tsvector('english', dct.content_text) @@ plainto_tsquery('english', p_search_query)
  ORDER BY relevance_score DESC
  LIMIT p_limit;
END;
$function$;

-- Update existing demo_responses with the new Q&A content
DELETE FROM public.demo_responses;

INSERT INTO public.demo_responses (id, question_text, answer_text, carrier_name)
VALUES 
(
  gen_random_uuid(),
  'Does Blue Ridge Logistics hire within 75 miles of Tulsa OK for regional reefer job BR-2317?',
  'Yes. Blue Ridge Logistics hires drivers within 100 miles of Tulsa, OK for regional reefer job BR-2317. Minimum requirements: CDL-A, 6 months experience, no more than 2 moving violations in the last 12 months. Average pay $1,500/week, home weekends.',
  'Blue Ridge Logistics'
),
(
  gen_random_uuid(),
  'What is IronSparrow Freight''s DUI and accident policy?',
  'IronSparrow Freight does not accept drivers with a DUI in the last 5 years. The carrier allows a maximum of 2 preventable accidents in the last 36 months and no more than 3 moving violations in 24 months.',
  'IronSparrow Freight'
),
(
  gen_random_uuid(),
  'What''s the average weekly pay and home time for Riverbend Carriers southeast regional job RB-339?',
  'Riverbend Carriers'' southeast regional job RB-339 averages $1,400–$1,600 weekly pay at ~2,500 miles. Drivers are home every weekend. Detention and layover pay are included.',
  'Riverbend Carriers'
),
(
  gen_random_uuid(),
  'Driver doesn''t want inward-facing cameras. Which carriers allow no cameras?',
  'Blue Ridge Logistics and Riverbend Carriers currently operate trucks without inward-facing cameras. Granite Coast Refrigerated requires inward cameras but offers a higher CPM to offset.',
  'Multiple Carriers'
);