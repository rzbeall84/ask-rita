-- Create organizations table to track query usage
CREATE TABLE IF NOT EXISTS public.organizations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  owner_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  monthly_query_cap INTEGER NOT NULL DEFAULT 1500,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create queries table to track AI query usage
CREATE TABLE IF NOT EXISTS public.queries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  query_text TEXT,
  response_text TEXT,
  tokens_used INTEGER,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.queries ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for organizations
CREATE POLICY "Users can view their own organization" ON public.organizations
FOR SELECT USING (owner_id = auth.uid());

CREATE POLICY "Users can update their own organization" ON public.organizations
FOR UPDATE USING (owner_id = auth.uid());

CREATE POLICY "Users can insert their own organization" ON public.organizations
FOR INSERT WITH CHECK (owner_id = auth.uid());

-- Create RLS policies for queries
CREATE POLICY "Users can view organization queries" ON public.queries
FOR SELECT USING (
  organization_id IN (
    SELECT id FROM public.organizations WHERE owner_id = auth.uid()
  )
);

CREATE POLICY "Users can insert organization queries" ON public.queries
FOR INSERT WITH CHECK (
  organization_id IN (
    SELECT id FROM public.organizations WHERE owner_id = auth.uid()
  )
);

-- Create helpful indexes
CREATE INDEX IF NOT EXISTS queries_org_time_idx ON public.queries (organization_id, created_at DESC);
CREATE INDEX IF NOT EXISTS organizations_owner_idx ON public.organizations (owner_id);

-- Helper function: get current month query count
CREATE OR REPLACE FUNCTION public.current_month_query_count(p_org UUID)
RETURNS INTEGER
LANGUAGE SQL
STABLE
AS $$
  SELECT COUNT(*)::INT
  FROM public.queries q
  WHERE q.organization_id = p_org
    AND date_trunc('month', q.created_at) = date_trunc('month', now());
$$;

-- Guard function: enforce cap on insert
CREATE OR REPLACE FUNCTION public.enforce_monthly_query_cap()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_cap INT;
  v_used INT;
BEGIN
  SELECT monthly_query_cap INTO v_cap
  FROM public.organizations
  WHERE id = NEW.organization_id;

  SELECT public.current_month_query_count(NEW.organization_id) INTO v_used;

  IF v_used >= v_cap THEN
    RAISE EXCEPTION 'Monthly AI query cap reached for this organization. Please upgrade or wait for the next cycle.'
      USING errcode = 'check_violation';
  END IF;

  RETURN NEW;
END;
$$;

-- Create trigger to enforce caps
DROP TRIGGER IF EXISTS trg_queries_enforce_cap ON public.queries;
CREATE TRIGGER trg_queries_enforce_cap
  BEFORE INSERT ON public.queries
  FOR EACH ROW
  EXECUTE FUNCTION public.enforce_monthly_query_cap();

-- Function to update query caps based on subscription
CREATE OR REPLACE FUNCTION public.update_organization_query_cap(p_org_id UUID, p_plan_type TEXT)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_new_cap INT;
BEGIN
  CASE p_plan_type
    WHEN 'starter' THEN v_new_cap := 1500;
    WHEN 'professional' THEN v_new_cap := 5000;
    ELSE v_new_cap := 1500; -- default to starter
  END CASE;

  UPDATE public.organizations
  SET monthly_query_cap = v_new_cap,
      updated_at = now()
  WHERE id = p_org_id;
END;
$$;