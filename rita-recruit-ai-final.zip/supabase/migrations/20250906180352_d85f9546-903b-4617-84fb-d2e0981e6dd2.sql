-- Remove the overly permissive RLS policy on demo_responses
DROP POLICY IF EXISTS "Demo responses are viewable by everyone" ON public.demo_responses;

-- Create a secure RLS policy that only allows access from Edge Functions (service role)
-- Service role bypasses RLS, so we create a policy that only allows authenticated service access
CREATE POLICY "Edge functions can access demo responses" 
ON public.demo_responses 
FOR SELECT 
USING (auth.role() = 'service_role');

-- Note: This policy will only allow access when using the service role key,
-- which will be used in the Edge Function for secure access to demo responses