-- Drop existing RLS policies and create organization-based policies

-- Update profiles RLS policies
DROP POLICY IF EXISTS "Users can create their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can view their own profile" ON public.profiles;

CREATE POLICY "Users can create their own profile"
ON public.profiles
FOR INSERT
WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can view profiles in their organization"
ON public.profiles
FOR SELECT
USING (
  organization_id IN (
    SELECT organization_id 
    FROM public.profiles 
    WHERE user_id = auth.uid()
  )
);

CREATE POLICY "Users can update their own profile"
ON public.profiles
FOR UPDATE
USING (user_id = auth.uid());

CREATE POLICY "Organization admins can update profiles in their org"
ON public.profiles
FOR UPDATE
USING (
  organization_id IN (
    SELECT organization_id 
    FROM public.profiles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
  )
);

-- Update organizations RLS policies
DROP POLICY IF EXISTS "Users can view their own organization" ON public.organizations;
DROP POLICY IF EXISTS "Users can update their own organization" ON public.organizations;
DROP POLICY IF EXISTS "Users can insert their own organization" ON public.organizations;

CREATE POLICY "Organization members can view their organization"
ON public.organizations
FOR SELECT
USING (
  id IN (
    SELECT organization_id 
    FROM public.profiles 
    WHERE user_id = auth.uid()
  )
);

CREATE POLICY "Organization owners can update their organization"
ON public.organizations
FOR UPDATE
USING (owner_id = auth.uid());

CREATE POLICY "Users can create organizations"
ON public.organizations
FOR INSERT
WITH CHECK (owner_id = auth.uid());

-- Update app_users RLS policies for organization-based admin access
DROP POLICY IF EXISTS "Users can view their invited users or admins see all" ON public.app_users;
DROP POLICY IF EXISTS "Users can update their invited users or admins update all" ON public.app_users;
DROP POLICY IF EXISTS "Users can delete their invited users or admins delete all" ON public.app_users;
DROP POLICY IF EXISTS "Users can create app users" ON public.app_users;

CREATE POLICY "Organization admins can view users in their org"
ON public.app_users
FOR SELECT
USING (
  invited_by IN (
    SELECT user_id 
    FROM public.profiles 
    WHERE organization_id = (
      SELECT organization_id 
      FROM public.profiles 
      WHERE user_id = auth.uid() 
      AND role = 'admin'
    )
  )
  OR invited_by = auth.uid()
);

CREATE POLICY "Organization admins can invite users to their org"
ON public.app_users
FOR INSERT
WITH CHECK (
  invited_by = auth.uid() 
  AND EXISTS (
    SELECT 1 
    FROM public.profiles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
  )
);

CREATE POLICY "Organization admins can update users in their org"
ON public.app_users
FOR UPDATE
USING (
  invited_by IN (
    SELECT user_id 
    FROM public.profiles 
    WHERE organization_id = (
      SELECT organization_id 
      FROM public.profiles 
      WHERE user_id = auth.uid() 
      AND role = 'admin'
    )
  )
  OR invited_by = auth.uid()
);

CREATE POLICY "Organization admins can delete users in their org"
ON public.app_users
FOR DELETE
USING (
  invited_by IN (
    SELECT user_id 
    FROM public.profiles 
    WHERE organization_id = (
      SELECT organization_id 
      FROM public.profiles 
      WHERE user_id = auth.uid() 
      AND role = 'admin'
    )
  )
  OR invited_by = auth.uid()
);

-- Update document-related tables for organization-based access

-- Document folders
DROP POLICY IF EXISTS "Users can view their own folders" ON public.document_folders;
DROP POLICY IF EXISTS "Users can create their own folders" ON public.document_folders;
DROP POLICY IF EXISTS "Users can update their own folders" ON public.document_folders;
DROP POLICY IF EXISTS "Users can delete their own folders" ON public.document_folders;

CREATE POLICY "Users can view folders in their organization"
ON public.document_folders
FOR SELECT
USING (
  user_id IN (
    SELECT user_id 
    FROM public.profiles 
    WHERE organization_id = (
      SELECT organization_id 
      FROM public.profiles 
      WHERE user_id = auth.uid()
    )
  )
);

CREATE POLICY "Users can create folders in their organization"
ON public.document_folders
FOR INSERT
WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update their own folders"
ON public.document_folders
FOR UPDATE
USING (user_id = auth.uid());

CREATE POLICY "Users can delete their own folders"
ON public.document_folders
FOR DELETE
USING (user_id = auth.uid());

-- Document files
DROP POLICY IF EXISTS "Users can view their own files" ON public.document_files;
DROP POLICY IF EXISTS "Users can create their own files" ON public.document_files;
DROP POLICY IF EXISTS "Users can update their own files" ON public.document_files;
DROP POLICY IF EXISTS "Users can delete their own files" ON public.document_files;

CREATE POLICY "Users can view files in their organization"
ON public.document_files
FOR SELECT
USING (
  user_id IN (
    SELECT user_id 
    FROM public.profiles 
    WHERE organization_id = (
      SELECT organization_id 
      FROM public.profiles 
      WHERE user_id = auth.uid()
    )
  )
);

CREATE POLICY "Users can create their own files"
ON public.document_files
FOR INSERT
WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update their own files"
ON public.document_files
FOR UPDATE
USING (user_id = auth.uid());

CREATE POLICY "Users can delete their own files"
ON public.document_files
FOR DELETE
USING (user_id = auth.uid());

-- Document content
DROP POLICY IF EXISTS "Users can view their own document content" ON public.document_content;
DROP POLICY IF EXISTS "Users can create their own document content" ON public.document_content;
DROP POLICY IF EXISTS "Users can update their own document content" ON public.document_content;

CREATE POLICY "Users can view document content in their organization"
ON public.document_content
FOR SELECT
USING (
  file_id IN (
    SELECT df.id 
    FROM public.document_files df
    JOIN public.profiles p ON df.user_id = p.user_id
    WHERE p.organization_id = (
      SELECT organization_id 
      FROM public.profiles 
      WHERE user_id = auth.uid()
    )
  )
);

CREATE POLICY "Users can create document content for their files"
ON public.document_content
FOR INSERT
WITH CHECK (
  file_id IN (
    SELECT id 
    FROM public.document_files 
    WHERE user_id = auth.uid()
  )
);

CREATE POLICY "Users can update document content for their files"
ON public.document_content
FOR UPDATE
USING (
  file_id IN (
    SELECT id 
    FROM public.document_files 
    WHERE user_id = auth.uid()
  )
);