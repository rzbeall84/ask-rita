-- Fix search path security issue for functions
CREATE OR REPLACE FUNCTION public.current_month_query_count(p_org UUID)
RETURNS INTEGER
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COUNT(*)::INT
  FROM public.queries q
  WHERE q.organization_id = p_org
    AND date_trunc('month', q.created_at) = date_trunc('month', now());
$$;

CREATE OR REPLACE FUNCTION public.enforce_monthly_query_cap()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_cap INT;
  v_used INT;
BEGIN
  SELECT monthly_query_cap INTO v_cap
  FROM public.organizations
  WHERE id = NEW.organization_id;

  SELECT public.current_month_query_count(NEW.organization_id) INTO v_used;

  IF v_used >= v_cap THEN
    RAISE EXCEPTION 'Monthly AI query cap reached for this organization. Please upgrade or wait for the next cycle.'
      USING errcode = 'check_violation';
  END IF;

  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_organization_query_cap(p_org_id UUID, p_plan_type TEXT)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_new_cap INT;
BEGIN
  CASE p_plan_type
    WHEN 'starter' THEN v_new_cap := 1500;
    WHEN 'professional' THEN v_new_cap := 5000;
    ELSE v_new_cap := 1500; -- default to starter
  END CASE;

  UPDATE public.organizations
  SET monthly_query_cap = v_new_cap,
      updated_at = now()
  WHERE id = p_org_id;
END;
$$;