-- Fix security issue: Update search_user_documents function with proper search_path
CREATE OR REPLACE FUNCTION public.search_user_documents(
  p_user_id UUID,
  p_search_query TEXT,
  p_limit INTEGER DEFAULT 5
)
RETURNS TABLE(
  file_id UUID,
  file_name TEXT,
  folder_name TEXT,
  category_name TEXT,
  content_snippet TEXT,
  relevance_score REAL
) 
LANGUAGE plpgsql 
SECURITY DEFINER 
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    df.id as file_id,
    df.file_name,
    dfo.name as folder_name,
    dc.name as category_name,
    LEFT(dct.content_text, 500) as content_snippet,
    ts_rank(to_tsvector('english', dct.content_text), plainto_tsquery('english', p_search_query)) as relevance_score
  FROM public.document_content dct
  JOIN public.document_files df ON dct.file_id = df.id
  JOIN public.document_folders dfo ON df.folder_id = dfo.id
  JOIN public.document_categories dc ON dfo.category_id = dc.id
  WHERE df.user_id = p_user_id 
    AND dct.processing_status = 'completed'
    AND to_tsvector('english', dct.content_text) @@ plainto_tsquery('english', p_search_query)
  ORDER BY relevance_score DESC
  LIMIT p_limit;
END;
$$;