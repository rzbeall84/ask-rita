import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "npm:resend@4.0.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";
import { renderAsync } from "npm:@react-email/components@0.0.22";
import React from "npm:react@18.3.1";
import { InviteEmail } from "./_templates/invite-email.tsx";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface InvitationRequest {
  to_email: string;
  first_name: string;
  last_name: string;
  invited_by: string;
  organization_id?: string;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return new Response("Method not allowed", { 
      status: 405, 
      headers: corsHeaders 
    });
  }

  try {
    console.log("Processing invitation request...");

    // Initialize Supabase client
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { persistSession: false } }
    );

    // Authenticate the request
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      throw new Error("No authorization header provided");
    }

    const token = authHeader.replace("Bearer ", "");
    const { data: userData, error: userError } = await supabase.auth.getUser(token);
    if (userError) throw new Error(`Authentication error: ${userError.message}`);
    
    const user = userData.user;
    if (!user) throw new Error("User not authenticated");

    // Verify user is admin
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('role, first_name, last_name, organization_id')
      .eq('user_id', user.id)
      .single();

    if (profileError || profile?.role !== 'admin') {
      throw new Error("Only administrators can send invitations");
    }

    const { 
      to_email, 
      first_name, 
      last_name, 
      invited_by,
      organization_id = profile.organization_id
    }: InvitationRequest = await req.json();

    if (!to_email || !first_name || !last_name || !invited_by) {
      return new Response(
        JSON.stringify({ error: "Missing required fields" }),
        {
          status: 400,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    // Generate secure invite token
    const inviteToken = crypto.randomUUID() + '-' + Date.now().toString(36);
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7); // 7 days expiration

    // Create or update app_users record with invite token
    const { data: existingUser, error: checkError } = await supabase
      .from('app_users')
      .select('id, status')
      .eq('email', to_email)
      .maybeSingle();

    if (checkError && checkError.code !== 'PGRST116') {
      throw new Error(`Error checking existing user: ${checkError.message}`);
    }

    let appUserId;
    
    if (existingUser) {
      // Update existing user with new invite token
      const { data: updatedUser, error: updateError } = await supabase
        .from('app_users')
        .update({
          invite_token: inviteToken,
          invite_expires_at: expiresAt.toISOString(),
          invited_by: user.id,
          status: 'pending'
        })
        .eq('id', existingUser.id)
        .select('id')
        .single();

      if (updateError) throw new Error(`Error updating user: ${updateError.message}`);
      appUserId = updatedUser.id;
      console.log("Updated existing app_user:", appUserId);
    } else {
      // Create new app_users record
      const { data: newUser, error: insertError } = await supabase
        .from('app_users')
        .insert({
          email: to_email,
          first_name,
          last_name,
          invite_token: inviteToken,
          invite_expires_at: expiresAt.toISOString(),
          invited_by: user.id,
          status: 'pending',
          has_access: true
        })
        .select('id')
        .single();

      if (insertError) throw new Error(`Error creating user: ${insertError.message}`);
      appUserId = newUser.id;
      console.log("Created new app_user:", appUserId);
    }

    // Create invite link with token
    const invite_link = `${req.headers.get("origin") || "https://askrita.org"}/signup?invite=${inviteToken}`;
    
    console.log("Generated invite link:", invite_link);

    // Render React email template
    const html = await renderAsync(
      React.createElement(InviteEmail, {
        invited_by: `${profile.first_name} ${profile.last_name}`,
        first_name,
        invite_link,
      })
    );

    const emailResponse = await resend.emails.send({
      from: "AskRita <noreply@askrita.org>",
      to: [to_email],
      subject: `${profile.first_name} ${profile.last_name} invited you to join AskRita`,
      html,
      text: `
Hi ${first_name},

${profile.first_name} ${profile.last_name} has invited you to join AskRita, the AI-powered recruiting platform designed for the transportation industry.

What you'll get access to:
• AI-powered candidate matching and screening
• Advanced driver qualification verification
• Comprehensive carrier database with insights
• Streamlined interview scheduling and management
• Collaborative hiring tools for your team
• Advanced analytics and reporting

Accept your invitation: ${invite_link}

This invitation expires in 7 days.
This invitation was sent by ${profile.first_name} ${profile.last_name}.

AskRita - Revolutionizing Transportation Recruiting
      `.trim(),
    });

    if (emailResponse.error) {
      throw emailResponse.error;
    }

    console.log("Invitation email sent successfully:", emailResponse);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: "Invitation sent successfully",
        email_id: emailResponse.data?.id 
      }),
      {
        status: 200,
        headers: {
          "Content-Type": "application/json",
          ...corsHeaders,
        },
      }
    );
  } catch (error: any) {
    console.error("Error sending invitation:", error);
    return new Response(
      JSON.stringify({ 
        error: "Failed to send invitation",
        details: error.message 
      }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);