import {
  Body,
  Container,
  Head,
  Heading,
  Html,
  Link,
  Preview,
  Text,
  Section,
  Button,
  Hr,
} from 'npm:@react-email/components@0.0.22'
import * as React from 'npm:react@18.3.1'

interface PasswordResetEmailProps {
  reset_link: string
  user_email: string
}

export const PasswordResetEmail = ({
  reset_link,
  user_email,
}: PasswordResetEmailProps) => (
  <Html>
    <Head />
    <Preview>Reset your AskRita password</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={header}>
          <div style={logoContainer}>
            <div style={logo}>AR</div>
          </div>
          <Heading style={h1}>AskRita</Heading>
          <Text style={tagline}>AI-Powered Recruiting Intelligence</Text>
        </Section>
        
        <Section style={content}>
          <Heading as="h2" style={contentTitle}>Reset Your Password</Heading>
          
          <Text style={message}>
            We received a request to reset the password for your AskRita account ({user_email}).
          </Text>

          <Section style={ctaSection}>
            <Button href={reset_link} style={ctaButton}>
              Reset Password
            </Button>
          </Section>

          <Text style={helpText}>
            This link will expire in 24 hours for security reasons.
          </Text>

          <Section style={securityBox}>
            <Text style={securityText}>
              <strong>🔒 Security Notice:</strong> If you didn't request this password reset, 
              please ignore this email. Your password will remain unchanged.
            </Text>
          </Section>

          <Text style={supportText}>
            If you're having trouble with the button above, copy and paste the following link into your browser:
            <br />
            <Link href={reset_link} style={resetLink}>{reset_link}</Link>
          </Text>
        </Section>

        <Hr style={hr} />
        
        <Section style={footer}>
          <Text style={footerText}>
            <Link href="https://askrita.org" style={footerLink}>AskRita</Link> • Revolutionizing Transportation Recruiting
            <br />
            If you need help, contact our support team.
          </Text>
        </Section>
      </Container>
    </Body>
  </Html>
)

export default PasswordResetEmail

const main = {
  backgroundColor: '#f8fafc',
  fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
  padding: '20px',
}

const container = {
  maxWidth: '600px',
  margin: '0 auto',
  backgroundColor: '#ffffff',
  borderRadius: '16px',
  boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
  overflow: 'hidden',
}

const header = {
  background: 'linear-gradient(135deg, #7c3aed 0%, #3b82f6 100%)',
  padding: '40px 30px',
  textAlign: 'center' as const,
}

const logoContainer = {
  marginBottom: '16px',
}

const logo = {
  width: '48px',
  height: '48px',
  backgroundColor: 'rgba(255, 255, 255, 0.2)',
  borderRadius: '12px',
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: '20px',
  fontWeight: '900',
  color: '#ffffff',
  margin: '0 auto',
}

const h1 = {
  color: '#ffffff',
  margin: '0 0 8px 0',
  fontSize: '28px',
  fontWeight: '900',
}

const tagline = {
  color: 'rgba(255, 255, 255, 0.9)',
  margin: '0',
  fontSize: '14px',
  fontWeight: '500',
}

const content = {
  padding: '40px 30px',
}

const contentTitle = {
  fontSize: '24px',
  marginBottom: '24px',
  color: '#1f2937',
  fontWeight: '700',
  textAlign: 'center' as const,
}

const message = {
  marginBottom: '32px',
  color: '#4b5563',
  fontSize: '16px',
  lineHeight: '1.6',
  textAlign: 'center' as const,
}

const ctaSection = {
  textAlign: 'center' as const,
  margin: '32px 0',
}

const ctaButton = {
  backgroundColor: '#7c3aed',
  background: 'linear-gradient(135deg, #7c3aed 0%, #3b82f6 100%)',
  color: '#ffffff',
  textDecoration: 'none',
  padding: '16px 32px',
  borderRadius: '12px',
  fontWeight: '600',
  fontSize: '16px',
  display: 'inline-block',
  boxShadow: '0 4px 14px 0 rgba(124, 58, 237, 0.39)',
}

const helpText = {
  marginBottom: '24px',
  color: '#6b7280',
  fontSize: '14px',
  lineHeight: '1.6',
  textAlign: 'center' as const,
}

const securityBox = {
  marginTop: '24px',
  padding: '16px',
  backgroundColor: '#fef2f2',
  borderRadius: '8px',
  borderLeft: '4px solid #ef4444',
}

const securityText = {
  margin: '0',
  color: '#dc2626',
  fontSize: '14px',
  lineHeight: '1.5',
}

const supportText = {
  marginTop: '32px',
  color: '#6b7280',
  fontSize: '12px',
  lineHeight: '1.6',
  textAlign: 'center' as const,
}

const resetLink = {
  color: '#7c3aed',
  textDecoration: 'none',
  wordBreak: 'break-all' as const,
}

const hr = {
  borderColor: '#e5e7eb',
  margin: '0',
}

const footer = {
  padding: '24px 30px',
  textAlign: 'center' as const,
}

const footerText = {
  color: '#6b7280',
  fontSize: '14px',
  lineHeight: '1.6',
  margin: '0',
}

const footerLink = {
  color: '#7c3aed',
  textDecoration: 'none',
  fontWeight: '600',
}