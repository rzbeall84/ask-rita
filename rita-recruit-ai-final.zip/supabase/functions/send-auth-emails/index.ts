import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "npm:resend@4.0.0";
import { renderAsync } from "npm:@react-email/components@0.0.22";
import React from "npm:react@18.3.1";
import { PasswordResetEmail } from "./_templates/password-reset.tsx";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface AuthEmailRequest {
  type: 'password_reset' | 'email_confirmation' | 'magic_link';
  user_email: string;
  reset_link?: string;
  confirmation_link?: string;
  magic_link?: string;
  user_name?: string;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return new Response("Method not allowed", { 
      status: 405, 
      headers: corsHeaders 
    });
  }

  try {
    console.log("Processing auth email request...");

    const { 
      type,
      user_email,
      reset_link,
      confirmation_link,
      magic_link,
      user_name = "User"
    }: AuthEmailRequest = await req.json();

    if (!type || !user_email) {
      return new Response(
        JSON.stringify({ error: "Missing required fields: type and user_email" }),
        {
          status: 400,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    let emailSubject = "";
    let html = "";
    let textContent = "";

    switch (type) {
      case 'password_reset':
        if (!reset_link) {
          throw new Error("reset_link is required for password reset emails");
        }
        
        html = await renderAsync(
          React.createElement(PasswordResetEmail, {
            reset_link,
            user_email,
          })
        );

        emailSubject = "Reset your AskRita password";
        textContent = `
Reset Your AskRita Password

We received a request to reset the password for your AskRita account (${user_email}).

Reset your password: ${reset_link}

This link will expire in 24 hours for security reasons.

If you didn't request this password reset, please ignore this email. Your password will remain unchanged.

AskRita - Revolutionizing Transportation Recruiting
        `.trim();
        break;

      case 'email_confirmation':
        if (!confirmation_link) {
          throw new Error("confirmation_link is required for email confirmation emails");
        }
        
        // For now, use a simple template - can be enhanced later
        html = `
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8">
            <title>Confirm Your AskRita Account</title>
          </head>
          <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background-color: #f8fafc; padding: 20px;">
            <div style="max-width: 600px; margin: 0 auto; background: white; border-radius: 16px; padding: 40px; text-align: center;">
              <h1 style="color: #7c3aed; margin-bottom: 20px;">Welcome to AskRita!</h1>
              <p style="color: #4b5563; margin-bottom: 30px;">Click the button below to confirm your email address and activate your account.</p>
              <a href="${confirmation_link}" style="display: inline-block; background: linear-gradient(135deg, #7c3aed 0%, #3b82f6 100%); color: white; text-decoration: none; padding: 16px 32px; border-radius: 12px; font-weight: 600;">Confirm Email Address</a>
              <p style="color: #6b7280; margin-top: 30px; font-size: 14px;">If you didn't create an account, you can safely ignore this email.</p>
            </div>
          </body>
        </html>
        `;

        emailSubject = "Confirm your AskRita account";
        textContent = `
Welcome to AskRita!

Click the link below to confirm your email address and activate your account:
${confirmation_link}

If you didn't create an account, you can safely ignore this email.

AskRita - Revolutionizing Transportation Recruiting
        `.trim();
        break;

      case 'magic_link':
        if (!magic_link) {
          throw new Error("magic_link is required for magic link emails");
        }
        
        // Simple magic link template
        html = `
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8">
            <title>Your AskRita Magic Link</title>
          </head>
          <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background-color: #f8fafc; padding: 20px;">
            <div style="max-width: 600px; margin: 0 auto; background: white; border-radius: 16px; padding: 40px; text-align: center;">
              <h1 style="color: #7c3aed; margin-bottom: 20px;">Sign in to AskRita</h1>
              <p style="color: #4b5563; margin-bottom: 30px;">Click the button below to sign in to your AskRita account.</p>
              <a href="${magic_link}" style="display: inline-block; background: linear-gradient(135deg, #7c3aed 0%, #3b82f6 100%); color: white; text-decoration: none; padding: 16px 32px; border-radius: 12px; font-weight: 600;">Sign In</a>
              <p style="color: #6b7280; margin-top: 30px; font-size: 14px;">This link will expire in 1 hour for security reasons.</p>
            </div>
          </body>
        </html>
        `;

        emailSubject = "Your AskRita sign-in link";
        textContent = `
Sign in to AskRita

Click the link below to sign in to your account:
${magic_link}

This link will expire in 1 hour for security reasons.

AskRita - Revolutionizing Transportation Recruiting
        `.trim();
        break;

      default:
        throw new Error(`Unsupported email type: ${type}`);
    }

    const emailResponse = await resend.emails.send({
      from: "AskRita <noreply@askrita.org>",
      to: [user_email],
      subject: emailSubject,
      html,
      text: textContent,
    });

    if (emailResponse.error) {
      throw emailResponse.error;
    }

    console.log(`${type} email sent successfully:`, emailResponse);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `${type} email sent successfully`,
        email_id: emailResponse.data?.id 
      }),
      {
        status: 200,
        headers: {
          "Content-Type": "application/json",
          ...corsHeaders,
        },
      }
    );
  } catch (error: any) {
    console.error("Error sending auth email:", error);
    return new Response(
      JSON.stringify({ 
        error: "Failed to send auth email",
        details: error.message 
      }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);