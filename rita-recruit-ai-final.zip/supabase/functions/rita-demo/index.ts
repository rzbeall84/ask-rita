import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.0';

const openAIApiKey = Deno.env.get('OPENAI_API_KEY');
const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
const supabaseServiceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Initialize Supabase clients
const supabase = createClient(supabaseUrl, supabaseAnonKey); // For demo documents (public access)
const supabaseServiceRole = createClient(supabaseUrl, supabaseServiceRoleKey); // For demo responses (secure access)

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { message } = await req.json();
    console.log('Demo chat received message:', message);

    if (!message) {
      throw new Error('Message is required');
    }

    // First, try to search demo documents for relevant content
    console.log('Searching demo documents...');
    const { data: searchResults, error: searchError } = await supabase
      .rpc('search_demo_documents', {
        p_search_query: message,
        p_limit: 3
      });

    if (!searchError && searchResults && searchResults.length > 0) {
      console.log('Found demo document results:', searchResults.length);
      
      // Build context from demo documents
      let documentContext = '';
      const sourceFiles = [];

      for (const result of searchResults) {
        documentContext += `\n\nFrom ${result.file_name} (${result.category_name} - ${result.folder_name}):\n${result.content_snippet}`;
        sourceFiles.push(`${result.file_name} (${result.category_name} - ${result.folder_name})`);
      }

      if (!openAIApiKey) {
        // Fallback to demo responses if no OpenAI key
        console.log('No OpenAI key, using demo responses fallback');
        const { data: demoResponse, error: demoError } = await supabaseServiceRole
          .from('demo_responses')
          .select('answer_text')
          .ilike('question_text', `%${message.split(' ').slice(0, 3).join(' ')}%`)
          .limit(1)
          .maybeSingle();

        if (!demoError && demoResponse) {
          console.log('Demo response matched');
          let responseText = demoResponse.answer_text;
          if (sourceFiles.length > 0) {
            responseText += `\n\n📄 Sources: ${sourceFiles.join(', ')}`;
          }
          return new Response(JSON.stringify({ response: responseText }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }
      } else {
        // Use OpenAI with document context
        console.log('Using OpenAI with document context, length:', documentContext.length);
        
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${openAIApiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            model: 'gpt-4o-mini',
            messages: [
              {
                role: 'system',
                content: `You are Rita, an AI recruiting assistant for the transportation industry. 

CRITICAL INSTRUCTIONS:
- Answer recruiter questions STRICTLY using the demo carrier and job information provided in the context below.
- If the answer cannot be found in the provided document context, respond EXACTLY with: "I wasn't able to find that in your files. Please upload the missing document or check with your manager."
- NEVER use external knowledge or make up information not contained in the provided context.
- Always cite which document(s) you're referencing in your response.
- Keep responses conversational but professional.
- This is a DEMO version - focus on showcasing the system's capabilities.

Document Context:
${documentContext}`
              },
              {
                role: 'user',
                content: message
              }
            ],
            max_tokens: 1000,
            temperature: 0.3,
          }),
        });

        if (!response.ok) {
          throw new Error(`OpenAI API error: ${response.status}`);
        }

        const data = await response.json();
        let aiMessage = data.choices[0].message.content;

        // Add source citation
        if (sourceFiles.length > 0) {
          aiMessage += `\n\n📄 Sources: ${sourceFiles.join(', ')}`;
        }

        console.log('Demo chat response generated successfully');
        return new Response(JSON.stringify({ response: aiMessage }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
    }

    // Fallback to original demo_responses table lookup
    console.log('Searching demo_responses table...');
    const { data: demoResponse, error: demoError } = await supabaseServiceRole
      .from('demo_responses')
      .select('answer_text, carrier_name')
      .ilike('question_text', `%${message.split(' ').slice(0, 3).join(' ')}%`)
      .limit(1)
      .maybeSingle();

    if (!demoError && demoResponse) {
      console.log('Demo response matched for:', message.split(' ').slice(0, 3).join(' '));
      return new Response(JSON.stringify({ response: demoResponse.answer_text }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // No matches found - use OpenAI for general response or fallback message
    if (openAIApiKey) {
      console.log('No demo matches, using OpenAI general response');
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${openAIApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'gpt-4o-mini',
          messages: [
            {
              role: 'system',
              content: `You are Rita, an AI recruiting assistant for the transportation industry. This is a DEMO version.

IMPORTANT LIMITATIONS:
- This demo only has information about specific carriers: Blue Ridge Logistics, IronSparrow Freight, Riverbend Carriers, and Granite Coast Refrigerated
- For questions about other carriers or topics, direct users to sign up for the full version
- Keep responses helpful but encourage users to upload their own documents for full functionality
- Be conversational and professional

Available demo topics:
- Blue Ridge Logistics regional reefer positions (job BR-2317, Tulsa area)
- IronSparrow Freight qualification policies (DUI/accident requirements)
- Riverbend Carriers southeast regional jobs (job RB-339, pay/home time)
- Camera policies across carriers`
            },
            {
              role: 'user',
              content: message
            }
          ],
          max_tokens: 500,
          temperature: 0.7,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        return new Response(JSON.stringify({ 
          response: data.choices[0].message.content + "\n\n💡 This is a demo with limited data. Sign up to upload your own documents and get answers about any carrier!"
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
    }

    // Final fallback message
    return new Response(JSON.stringify({ 
      response: "This is a demo with limited sample data. To get answers about your specific carriers and positions, please sign up and upload your documents!"
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in rita-demo function:', error);
    return new Response(JSON.stringify({ 
      response: "I'm having trouble processing your request. This is a demo with sample data - sign up to access the full system!"
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});