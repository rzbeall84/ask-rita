import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "npm:resend@4.0.0";
import { renderAsync } from "npm:@react-email/components@0.0.22";
import React from "npm:react@18.3.1";
import { WelcomeEmail } from "./_templates/welcome-email.tsx";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface TransactionalEmailRequest {
  type: 'welcome' | 'payment_confirmation' | 'subscription_change';
  user_email: string;
  user_name: string;
  plan_name?: string;
  amount?: number;
  currency?: string;
  invoice_url?: string;
  login_link?: string;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return new Response("Method not allowed", { 
      status: 405, 
      headers: corsHeaders 
    });
  }

  try {
    console.log("Processing transactional email request...");

    const { 
      type,
      user_email,
      user_name,
      plan_name = "Starter",
      amount,
      currency = "USD",
      invoice_url,
      login_link = "https://askrita.org/login"
    }: TransactionalEmailRequest = await req.json();

    if (!type || !user_email || !user_name) {
      return new Response(
        JSON.stringify({ error: "Missing required fields: type, user_email, and user_name" }),
        {
          status: 400,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    let emailSubject = "";
    let html = "";
    let textContent = "";

    switch (type) {
      case 'welcome':
        html = await renderAsync(
          React.createElement(WelcomeEmail, {
            user_name,
            login_link,
            plan_name,
          })
        );

        emailSubject = `Welcome to AskRita! Your ${plan_name} subscription is active`;
        textContent = `
Welcome to AskRita!

Hi ${user_name},

Congratulations! Your ${plan_name} subscription is now active. You're all set to revolutionize your transportation recruiting process with AI-powered tools.

You now have access to:
• AI-powered candidate matching and screening
• Advanced driver qualification verification
• Comprehensive carrier database with insights
• Streamlined interview scheduling and management
• Collaborative hiring tools for your team
• Advanced analytics and reporting
• Priority customer support

Get started: ${login_link}

Next Steps:
1. Complete your organization profile
2. Upload your first job posting
3. Explore the AI-powered candidate matching
4. Invite your team members

Questions? Contact our customer success team anytime.

AskRita - Revolutionizing Transportation Recruiting
        `.trim();
        break;

      case 'payment_confirmation':
        const formattedAmount = amount ? (amount / 100).toFixed(2) : "0.00";
        
        html = `
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8">
            <title>Payment Confirmation - AskRita</title>
          </head>
          <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background-color: #f8fafc; padding: 20px;">
            <div style="max-width: 600px; margin: 0 auto; background: white; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);">
              <div style="background: linear-gradient(135deg, #7c3aed 0%, #3b82f6 100%); padding: 40px 30px; text-align: center;">
                <div style="width: 48px; height: 48px; background: rgba(255, 255, 255, 0.2); border-radius: 12px; display: inline-flex; align-items: center; justify-content: center; font-size: 20px; font-weight: 900; color: #ffffff; margin-bottom: 16px;">AR</div>
                <h1 style="color: #ffffff; margin: 0 0 8px 0; font-size: 28px; font-weight: 900;">AskRita</h1>
                <p style="color: rgba(255, 255, 255, 0.9); margin: 0; font-size: 14px; font-weight: 500;">AI-Powered Recruiting Intelligence</p>
              </div>
              
              <div style="padding: 40px 30px;">
                <h2 style="font-size: 24px; margin-bottom: 24px; color: #1f2937; font-weight: 700; text-align: center;">Payment Confirmed</h2>
                
                <p style="color: #4b5563; margin-bottom: 32px; font-size: 16px; line-height: 1.6;">
                  Hi ${user_name},<br><br>
                  Thank you for your payment! Your ${plan_name} subscription payment of <strong>${currency} $${formattedAmount}</strong> has been successfully processed.
                </p>

                <div style="background: #f0fdf4; padding: 24px; border-radius: 12px; border: 1px solid #bbf7d0; margin: 32px 0;">
                  <h3 style="color: #166534; margin: 0 0 16px 0; font-size: 18px; font-weight: 700;">✅ Payment Details:</h3>
                  <ul style="color: #166534; margin: 0; padding-left: 20px;">
                    <li>Plan: ${plan_name}</li>
                    <li>Amount: ${currency} $${formattedAmount}</li>
                    <li>Date: ${new Date().toLocaleDateString()}</li>
                  </ul>
                </div>

                ${invoice_url ? `
                <div style="text-align: center; margin: 32px 0;">
                  <a href="${invoice_url}" style="display: inline-block; background: linear-gradient(135deg, #7c3aed 0%, #3b82f6 100%); color: white; text-decoration: none; padding: 16px 32px; border-radius: 12px; font-weight: 600; font-size: 16px; box-shadow: 0 4px 14px 0 rgba(124, 58, 237, 0.39);">
                    View Invoice
                  </a>
                </div>
                ` : ''}

                <p style="color: #6b7280; font-size: 14px; line-height: 1.6; text-align: center; margin-top: 32px;">
                  If you have any questions about your payment, please contact our support team.
                </p>
              </div>

              <div style="border-top: 1px solid #e5e7eb; padding: 24px 30px; text-align: center;">
                <p style="color: #6b7280; font-size: 14px; line-height: 1.6; margin: 0;">
                  <a href="https://askrita.org" style="color: #7c3aed; text-decoration: none; font-weight: 600;">AskRita</a> • Revolutionizing Transportation Recruiting
                </p>
              </div>
            </div>
          </body>
        </html>
        `;

        emailSubject = `Payment confirmed for your ${plan_name} subscription`;
        textContent = `
Payment Confirmed - AskRita

Hi ${user_name},

Thank you for your payment! Your ${plan_name} subscription payment of ${currency} $${formattedAmount} has been successfully processed.

Payment Details:
• Plan: ${plan_name}
• Amount: ${currency} $${formattedAmount}
• Date: ${new Date().toLocaleDateString()}

${invoice_url ? `View your invoice: ${invoice_url}` : ''}

If you have any questions about your payment, please contact our support team.

AskRita - Revolutionizing Transportation Recruiting
        `.trim();
        break;

      case 'subscription_change':
        html = `
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8">
            <title>Subscription Update - AskRita</title>
          </head>
          <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background-color: #f8fafc; padding: 20px;">
            <div style="max-width: 600px; margin: 0 auto; background: white; border-radius: 16px; padding: 40px; text-align: center;">
              <h1 style="color: #7c3aed; margin-bottom: 20px;">Subscription Updated</h1>
              <p style="color: #4b5563; margin-bottom: 30px;">
                Hi ${user_name},<br><br>
                Your AskRita subscription has been updated to <strong>${plan_name}</strong>.
              </p>
              <a href="${login_link}" style="display: inline-block; background: linear-gradient(135deg, #7c3aed 0%, #3b82f6 100%); color: white; text-decoration: none; padding: 16px 32px; border-radius: 12px; font-weight: 600;">
                Access Your Account
              </a>
              <p style="color: #6b7280; margin-top: 30px; font-size: 14px;">
                Questions? Contact our support team anytime.
              </p>
            </div>
          </body>
        </html>
        `;

        emailSubject = `Your AskRita subscription has been updated`;
        textContent = `
Subscription Updated - AskRita

Hi ${user_name},

Your AskRita subscription has been updated to ${plan_name}.

Access your account: ${login_link}

Questions? Contact our support team anytime.

AskRita - Revolutionizing Transportation Recruiting
        `.trim();
        break;

      default:
        throw new Error(`Unsupported email type: ${type}`);
    }

    const emailResponse = await resend.emails.send({
      from: "AskRita <noreply@askrita.org>",
      to: [user_email],
      subject: emailSubject,
      html,
      text: textContent,
    });

    if (emailResponse.error) {
      throw emailResponse.error;
    }

    console.log(`${type} email sent successfully:`, emailResponse);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `${type} email sent successfully`,
        email_id: emailResponse.data?.id 
      }),
      {
        status: 200,
        headers: {
          "Content-Type": "application/json",
          ...corsHeaders,
        },
      }
    );
  } catch (error: any) {
    console.error("Error sending transactional email:", error);
    return new Response(
      JSON.stringify({ 
        error: "Failed to send transactional email",
        details: error.message 
      }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);