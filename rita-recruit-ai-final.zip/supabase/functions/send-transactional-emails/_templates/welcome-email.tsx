import {
  Body,
  Container,
  Head,
  Heading,
  Html,
  Link,
  Preview,
  Text,
  Section,
  Button,
  Hr,
} from 'npm:@react-email/components@0.0.22'
import * as React from 'npm:react@18.3.1'

interface WelcomeEmailProps {
  user_name: string
  login_link: string
  plan_name: string
}

export const WelcomeEmail = ({
  user_name,
  login_link,
  plan_name,
}: WelcomeEmailProps) => (
  <Html>
    <Head />
    <Preview>Welcome to AskRita - Your subscription is active!</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={header}>
          <div style={logoContainer}>
            <div style={logo}>AR</div>
          </div>
          <Heading style={h1}>AskRita</Heading>
          <Text style={tagline}>AI-Powered Recruiting Intelligence</Text>
        </Section>
        
        <Section style={content}>
          <Heading as="h2" style={contentTitle}>Welcome to AskRita!</Heading>
          
          <Text style={greeting}>Hi {user_name},</Text>
          
          <Text style={message}>
            Congratulations! Your <strong>{plan_name}</strong> subscription is now active. 
            You're all set to revolutionize your transportation recruiting process with AI-powered tools.
          </Text>

          <Section style={features}>
            <Heading as="h3" style={featuresTitle}>🎉 You now have access to:</Heading>
            <ul style={featuresList}>
              <li style={featureItem}>AI-powered candidate matching and screening</li>
              <li style={featureItem}>Advanced driver qualification verification</li>
              <li style={featureItem}>Comprehensive carrier database with insights</li>
              <li style={featureItem}>Streamlined interview scheduling and management</li>
              <li style={featureItem}>Collaborative hiring tools for your team</li>
              <li style={featureItem}>Advanced analytics and reporting</li>
              <li style={featureItem}>Priority customer support</li>
            </ul>
          </Section>

          <Section style={ctaSection}>
            <Button href={login_link} style={ctaButton}>
              Get Started Now
            </Button>
          </Section>

          <Section style={nextSteps}>
            <Heading as="h3" style={nextStepsTitle}>🚀 Next Steps:</Heading>
            <ol style={stepsList}>
              <li style={stepItem}>Complete your organization profile</li>
              <li style={stepItem}>Upload your first job posting</li>
              <li style={stepItem}>Explore the AI-powered candidate matching</li>
              <li style={stepItem}>Invite your team members</li>
            </ol>
          </Section>

          <Section style={supportBox}>
            <Text style={supportText}>
              <strong>📞 Need Help?</strong><br />
              Our customer success team is here to help you get the most out of AskRita. 
              Don't hesitate to reach out if you have any questions.
            </Text>
          </Section>
        </Section>

        <Hr style={hr} />
        
        <Section style={footer}>
          <Text style={footerText}>
            <Link href="https://askrita.org" style={footerLink}>AskRita</Link> • Revolutionizing Transportation Recruiting
            <br />
            Questions? Contact our support team anytime.
          </Text>
        </Section>
      </Container>
    </Body>
  </Html>
)

export default WelcomeEmail

const main = {
  backgroundColor: '#f8fafc',
  fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
  padding: '20px',
}

const container = {
  maxWidth: '600px',
  margin: '0 auto',
  backgroundColor: '#ffffff',
  borderRadius: '16px',
  boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
  overflow: 'hidden',
}

const header = {
  background: 'linear-gradient(135deg, #7c3aed 0%, #3b82f6 100%)',
  padding: '40px 30px',
  textAlign: 'center' as const,
}

const logoContainer = {
  marginBottom: '16px',
}

const logo = {
  width: '48px',
  height: '48px',
  backgroundColor: 'rgba(255, 255, 255, 0.2)',
  borderRadius: '12px',
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: '20px',
  fontWeight: '900',
  color: '#ffffff',
  margin: '0 auto',
}

const h1 = {
  color: '#ffffff',
  margin: '0 0 8px 0',
  fontSize: '28px',
  fontWeight: '900',
}

const tagline = {
  color: 'rgba(255, 255, 255, 0.9)',
  margin: '0',
  fontSize: '14px',
  fontWeight: '500',
}

const content = {
  padding: '40px 30px',
}

const contentTitle = {
  fontSize: '24px',
  marginBottom: '24px',
  color: '#1f2937',
  fontWeight: '700',
  textAlign: 'center' as const,
}

const greeting = {
  fontSize: '18px',
  marginBottom: '16px',
  color: '#1f2937',
  fontWeight: '600',
}

const message = {
  marginBottom: '32px',
  color: '#4b5563',
  fontSize: '16px',
  lineHeight: '1.6',
}

const features = {
  margin: '32px 0',
  padding: '24px',
  backgroundColor: '#f0fdf4',
  borderRadius: '12px',
  border: '1px solid #bbf7d0',
}

const featuresTitle = {
  margin: '0 0 16px 0',
  color: '#166534',
  fontSize: '18px',
  fontWeight: '700',
}

const featuresList = {
  margin: '0',
  paddingLeft: '20px',
  color: '#166534',
}

const featureItem = {
  marginBottom: '8px',
  lineHeight: '1.5',
}

const ctaSection = {
  textAlign: 'center' as const,
  margin: '32px 0',
}

const ctaButton = {
  backgroundColor: '#7c3aed',
  background: 'linear-gradient(135deg, #7c3aed 0%, #3b82f6 100%)',
  color: '#ffffff',
  textDecoration: 'none',
  padding: '16px 32px',
  borderRadius: '12px',
  fontWeight: '600',
  fontSize: '16px',
  display: 'inline-block',
  boxShadow: '0 4px 14px 0 rgba(124, 58, 237, 0.39)',
}

const nextSteps = {
  margin: '32px 0',
  padding: '24px',
  backgroundColor: '#fef3c7',
  borderRadius: '12px',
  border: '1px solid #fde68a',
}

const nextStepsTitle = {
  margin: '0 0 16px 0',
  color: '#92400e',
  fontSize: '18px',
  fontWeight: '700',
}

const stepsList = {
  margin: '0',
  paddingLeft: '20px',
  color: '#92400e',
}

const stepItem = {
  marginBottom: '8px',
  lineHeight: '1.5',
}

const supportBox = {
  marginTop: '32px',
  padding: '16px',
  backgroundColor: '#eff6ff',
  borderRadius: '8px',
  borderLeft: '4px solid #3b82f6',
}

const supportText = {
  margin: '0',
  color: '#1e40af',
  fontSize: '14px',
  lineHeight: '1.5',
}

const hr = {
  borderColor: '#e5e7eb',
  margin: '0',
}

const footer = {
  padding: '24px 30px',
  textAlign: 'center' as const,
}

const footerText = {
  color: '#6b7280',
  fontSize: '14px',
  lineHeight: '1.6',
  margin: '0',
}

const footerLink = {
  color: '#7c3aed',
  textDecoration: 'none',
  fontWeight: '600',
}