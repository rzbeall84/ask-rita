import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.0';

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { fileId } = await req.json();
    
    if (!fileId) {
      throw new Error('File ID is required');
    }

    console.log('Processing document extraction for file ID:', fileId);

    // Initialize Supabase client with service role key
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get file information
    const { data: fileData, error: fileError } = await supabase
      .from('document_files')
      .select('*')
      .eq('id', fileId)
      .single();

    if (fileError || !fileData) {
      console.error('Error fetching file:', fileError);
      throw new Error('File not found');
    }

    console.log('File data:', fileData);

    // Download file from Supabase storage
    const { data: fileBlob, error: downloadError } = await supabase.storage
      .from('documents')
      .download(fileData.file_path);

    if (downloadError) {
      console.error('Error downloading file:', downloadError);
      throw new Error('Failed to download file');
    }

    // Convert blob to text (basic text extraction for now)
    let extractedText = '';
    
    try {
      // For text files, PDFs would need more sophisticated parsing
      if (fileData.file_type?.includes('text') || fileData.file_name.endsWith('.txt')) {
        extractedText = await fileBlob.text();
      } else {
        // For other file types, we'll use a simple approach for now
        // In production, you'd want to use libraries like pdf-parse for PDFs
        extractedText = `Content extracted from ${fileData.file_name}. This file requires manual processing for full text extraction.`;
      }
    } catch (textError) {
      console.error('Error extracting text:', textError);
      extractedText = `Unable to extract text from ${fileData.file_name}. Manual processing may be required.`;
    }

    console.log('Extracted text length:', extractedText.length);

    // Create a summary using the first 200 characters
    const summary = extractedText.substring(0, 200) + (extractedText.length > 200 ? '...' : '');

    // Store extracted content in database
    const { error: insertError } = await supabase
      .from('document_content')
      .upsert({
        file_id: fileId,
        content_text: extractedText,
        content_summary: summary,
        processing_status: 'completed',
        extracted_at: new Date().toISOString()
      }, {
        onConflict: 'file_id'
      });

    if (insertError) {
      console.error('Error storing document content:', insertError);
      throw new Error('Failed to store extracted content');
    }

    // Update file processing status
    const { error: updateError } = await supabase
      .from('document_files')
      .update({
        processing_status: 'completed',
        has_content: true
      })
      .eq('id', fileId);

    if (updateError) {
      console.error('Error updating file status:', updateError);
    }

    console.log('Document processing completed successfully');

    return new Response(JSON.stringify({
      success: true,
      message: 'Document processed successfully',
      textLength: extractedText.length
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in extract-document-text function:', error);
    return new Response(JSON.stringify({
      error: 'Failed to process document',
      details: error.message
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});