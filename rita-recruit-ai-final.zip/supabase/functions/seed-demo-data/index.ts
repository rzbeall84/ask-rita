import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.0';

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Starting demo data seeding...');

    // Initialize Supabase client with service key for admin access
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Demo constants
    const DEMO_ORG_ID = '00000000-0000-0000-0000-000000000000';
    const DEMO_USER_ID = '22222222-2222-2222-2222-222222222222'; 
    
    // Demo Q&A data
    const demoDocuments = [
      {
        title: "Blue Ridge Logistics Regional Reefer Job BR-2317",
        content: `# Blue Ridge Logistics - Regional Reefer Job BR-2317

**Job Code:** BR-2317
**Position:** Regional Reefer Driver
**Hiring Area:** Within 100 miles of Tulsa, OK

## Requirements:
- CDL-A license required
- Minimum 6 months experience
- No more than 2 moving violations in the last 12 months
- Clean driving record

## Compensation:
- Average weekly pay: $1,500
- Mileage-based pay structure
- Performance bonuses available

## Schedule:
- Home weekends guaranteed
- Regional routes throughout the Southwest
- Predictable schedule

## Equipment:
- Late model refrigerated trailers
- No inward-facing cameras
- Well-maintained fleet

Blue Ridge Logistics is actively hiring qualified drivers in the Tulsa, OK area for this position.`,
        filename: "blue_ridge_job_br2317.md"
      },
      {
        title: "IronSparrow Freight Driver Qualification Policy",
        content: `# IronSparrow Freight - Driver Qualification & Safety Policy

## DUI Policy:
- **Strict 5-year lookback period for DUI/DWI convictions**
- No exceptions for DUI violations within 5 years
- Must provide complete driving record for verification

## Accident Policy:
- Maximum of 2 preventable accidents allowed in the last 36 months
- Each accident will be reviewed for preventability determination
- Accidents involving fatalities are disqualifying regardless of fault

## Moving Violations:
- No more than 3 moving violations in the last 24 months
- Serious violations (reckless driving, excessive speeding 15+ mph over) may be disqualifying
- Traffic citations must be disclosed during application

## Background Requirements:
- Clean criminal background check
- No felonies involving violence, theft, or drugs in the last 7 years
- Must pass DOT physical and drug screening

## Verification Process:
All driving records are verified through official state DMV records and PSP reports.

*Policy updated: September 2024*`,
        filename: "ironsparrow_qualification_policy.md"
      },
      {
        title: "Riverbend Carriers Southeast Regional Job RB-339",
        content: `# Riverbend Carriers - Southeast Regional Position RB-339

**Job Code:** RB-339
**Route:** Southeast Regional
**Coverage Area:** GA, FL, SC, NC, TN, AL

## Weekly Statistics:
- **Average Weekly Miles:** 2,500 miles
- **Average Weekly Pay:** $1,400 - $1,600
- **Pay Structure:** $0.56 - $0.64 per mile based on experience

## Home Time:
- **Guaranteed home every weekend**
- Typically home Friday evening through Sunday evening
- Extra time off during holidays

## Additional Pay:
- Detention pay: $15/hour after 2 hours
- Layover pay: $75/day
- Breakdown pay: Full day's pay
- Safety bonuses quarterly

## Equipment & Benefits:
- 2020+ Freightliner Cascadia tractors
- No inward-facing cameras policy
- Full benefits package including health, dental, vision
- 401k with company match
- Paid vacation and sick leave

## Requirements:
- CDL-A with clean record
- 1+ years OTR experience preferred
- Pass DOT physical and drug screen
- Able to work weekends occasionally

Contact recruiting for immediate opportunities.`,
        filename: "riverbend_job_rb339.md"
      },
      {
        title: "Carrier Camera Policies Comparison",
        content: `# Transportation Company Camera Policies - 2024

## Companies WITHOUT Inward-Facing Cameras:

### Blue Ridge Logistics
- **Camera Policy:** Outward-facing only
- **Reasoning:** Driver privacy priority
- **Driver Feedback:** Positive response from drivers
- **Safety Program:** Focus on training and coaching

### Riverbend Carriers  
- **Camera Policy:** Road-facing cameras only
- **Driver Privacy:** Strict no inward-facing camera policy
- **Monitoring:** GPS tracking for location only
- **Alternative:** Quarterly safety meetings and bonuses

## Companies WITH Inward-Facing Cameras:

### Granite Coast Refrigerated
- **Camera Policy:** Full dual-facing camera system
- **Compensation:** Higher CPM rate (+$0.08) to offset privacy concerns
- **Justification:** Insurance requirements and safety program
- **Driver Benefits:** 
  - Accident protection and exoneration
  - Faster claim resolution
  - Performance-based bonuses

### Industry Trend:
Most major carriers are moving toward camera systems for insurance and safety compliance, but several smaller to mid-size companies maintain no-camera policies to attract drivers who value privacy.

**Driver Preference Survey (2024):** 73% of drivers prefer no inward-facing cameras when compensation is equal.`,
        filename: "camera_policies_comparison.md"
      }
    ];

    // Get or create demo folder
    let { data: folders, error: folderError } = await supabase
      .from('document_folders')
      .select('id, category_id')
      .eq('name', 'Carrier Information & Job Details')
      .limit(1);

    let folderId: string;
    let categoryId: string;

    if (!folders || folders.length === 0) {
      console.log('Creating demo folder...');
      
      // Get Recruiting Practices category
      const { data: categories } = await supabase
        .from('document_categories')
        .select('id')
        .eq('name', 'Recruiting Practices')
        .limit(1);

      if (!categories || categories.length === 0) {
        throw new Error('Recruiting Practices category not found');
      }

      categoryId = categories[0].id;
      
      // Create folder (will need a real user_id, so let's use the first available user)
      const { data: users } = await supabase
        .from('profiles')
        .select('user_id')
        .limit(1);

      if (!users || users.length === 0) {
        throw new Error('No users found - cannot create demo folder');
      }

      const { data: newFolder, error: createFolderError } = await supabase
        .from('document_folders')
        .insert({
          name: 'Carrier Information & Job Details',
          description: 'Demo seed data for carrier policies and job information',
          category_id: categoryId,
          user_id: users[0].user_id,
          is_hidden: false,
          openai_instructions: 'Use this information to answer questions about carrier policies, job requirements, and hiring criteria.'
        })
        .select('id')
        .single();

      if (createFolderError) {
        console.error('Error creating folder:', createFolderError);
        throw createFolderError;
      }

      folderId = newFolder.id;
    } else {
      folderId = folders[0].id;
      categoryId = folders[0].category_id;
    }

    console.log(`Using folder ID: ${folderId}`);

    // Process each demo document
    for (const doc of demoDocuments) {
      console.log(`Processing document: ${doc.title}`);

      // Store file in Supabase Storage
      const filePath = `demo/${doc.filename}`;
      const { error: storageError } = await supabase.storage
        .from('documents')
        .upload(filePath, new Blob([doc.content], { type: 'text/markdown' }), {
          upsert: true
        });

      if (storageError) {
        console.error(`Storage error for ${doc.filename}:`, storageError);
        continue;
      }

      // Insert document_files record
      const { data: docFile, error: docError } = await supabase
        .from('document_files')
        .insert({
          file_name: doc.filename,
          file_path: filePath,
          file_type: 'text/markdown',
          file_size: doc.content.length,
          folder_id: folderId,
          user_id: DEMO_USER_ID, // This will be the demo user
          organization_id: DEMO_ORG_ID,
          source: 'seed',
          processing_status: 'completed',
          has_content: true
        })
        .select('id')
        .single();

      if (docError) {
        console.error(`Document files error for ${doc.filename}:`, docError);
        continue;
      }

      // Insert document_content record
      const { error: contentError } = await supabase
        .from('document_content')
        .insert({
          file_id: docFile.id,
          content_text: doc.content,
          content_summary: doc.title,
          processing_status: 'completed'
        });

      if (contentError) {
        console.error(`Document content error for ${doc.filename}:`, contentError);
        continue;
      }

      console.log(`Successfully seeded: ${doc.filename}`);
    }

    return new Response(JSON.stringify({ 
      success: true, 
      message: `Successfully seeded ${demoDocuments.length} demo documents`,
      folder_id: folderId 
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error seeding demo data:', error);
    return new Response(JSON.stringify({ 
      error: error.message 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});