import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@14.21.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const logStep = (step: string, details?: any) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[STRIPE-WEBHOOK] ${step}${detailsStr}`);
};

serve(async (req) => {
  try {
    logStep("Webhook received");

    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    if (!stripeKey) throw new Error("STRIPE_SECRET_KEY is not set");

    const stripe = new Stripe(stripeKey, { apiVersion: "2023-10-16" });
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { persistSession: false } }
    );

    const signature = req.headers.get("stripe-signature");
    const body = await req.text();

    let event: Stripe.Event;
    try {
      event = stripe.webhooks.constructEvent(
        body,
        signature!,
        Deno.env.get("STRIPE_WEBHOOK_SECRET") || ""
      );
    } catch (err) {
      logStep("Webhook signature verification failed", { error: err });
      return new Response("Webhook signature verification failed", { status: 400 });
    }

    logStep("Processing event", { type: event.type, id: event.id });

    switch (event.type) {
      case "customer.subscription.created":
      case "customer.subscription.updated": {
        const subscription = event.data.object as Stripe.Subscription;
        const customerId = subscription.customer as string;
        
        // Get customer to find user email
        const customer = await stripe.customers.retrieve(customerId) as Stripe.Customer;
        if (!customer.email) {
          logStep("No email found for customer", { customerId });
          break;
        }

        // Find user by email
        const { data: users } = await supabaseClient.auth.admin.listUsers();
        const user = users.users.find(u => u.email === customer.email);
        if (!user) {
          logStep("No user found for email", { email: customer.email });
          break;
        }

        // Enhanced plan detection with intro and standard pricing support
        const amount = subscription.items.data[0].price.unit_amount || 0;
        const priceId = subscription.items.data[0].price.id;
        let planType = 'starter';
        let storageLimit = 20;
        let queryLimit = 1500;
        
        // Determine plan type based on price ranges (supporting both intro and standard pricing)
        if (amount >= 99000 && amount <= 120000) {
          planType = 'enterprise';
          storageLimit = 500;
          queryLimit = 15000;
        } else if (amount >= 35000 && amount <= 49900) {
          planType = 'pro';
          storageLimit = 100;
          queryLimit = 5000;
        } else {
          planType = 'starter';
          storageLimit = 20;
          queryLimit = 1500;
        }

        // Determine intro period status based on price
        const isIntroPrice = amount === 15000 || amount === 35000 || amount === 99000;
        const introPriceIds = {
          starter: 'price_1S6I6GDlNVaqt2O2yJ9SPdLv',
          pro: 'price_1S6I76DlNVaqt2O2BOXXDRnc',
          enterprise: 'price_1S6I7eDlNVaqt2O2LeKNOhWb'
        };
        const standardPriceIds = {
          starter: 'price_1S6I6UDlNVaqt2O28q2gnpJs',
          pro: 'price_1S6I7RDlNVaqt2O2MZjs4ZHC',
          enterprise: 'price_1S6I7pDlNVaqt2O2uaAKShfC'
        };
        
        const introCyclesRemaining = isIntroPrice ? 3 : 0;
        const introEndDate = isIntroPrice ? 
          new Date(subscription.current_period_end * 1000 + (2 * 30 * 24 * 60 * 60 * 1000)) : 
          null;

        await supabaseClient.from("subscriptions").upsert({
          user_id: user.id,
          stripe_customer_id: customerId,
          stripe_subscription_id: subscription.id,
          status: subscription.status,
          plan_type: planType,
          storage_limit_gb: storageLimit,
          query_limit: queryLimit,
          stripe_price_id: priceId,
          intro_period_active: isIntroPrice,
          intro_cycles_remaining: introCyclesRemaining,
          intro_price_id: introPriceIds[planType as keyof typeof introPriceIds],
          standard_price_id: standardPriceIds[planType as keyof typeof standardPriceIds],
          intro_end_date: introEndDate?.toISOString(),
          current_period_start: new Date(subscription.current_period_start * 1000).toISOString(),
          current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
          updated_at: new Date().toISOString(),
        }, { onConflict: 'user_id' });

        // Update organization query cap based on subscription
        await supabaseClient.rpc('update_organization_query_cap', {
          p_org_id: (await supabaseClient.from('profiles').select('organization_id').eq('user_id', user.id).single()).data?.organization_id,
          p_plan_type: planType
        });

        logStep("Subscription updated", { userId: user.id, planType, status: subscription.status });
        break;
      }

      case "customer.subscription.deleted": {
        const subscription = event.data.object as Stripe.Subscription;
        const customerId = subscription.customer as string;
        
        // Get customer to find user email
        const customer = await stripe.customers.retrieve(customerId) as Stripe.Customer;
        if (!customer.email) break;

        // Find user by email
        const { data: users } = await supabaseClient.auth.admin.listUsers();
        const user = users.users.find(u => u.email === customer.email);
        if (!user) break;

        await supabaseClient.from("subscriptions").upsert({
          user_id: user.id,
          stripe_customer_id: customerId,
          stripe_subscription_id: null,
          status: 'inactive',
          plan_type: null,
          current_period_start: null,
          current_period_end: null,
          updated_at: new Date().toISOString(),
        }, { onConflict: 'user_id' });

        logStep("Subscription cancelled", { userId: user.id });
        break;
      }

      default:
        logStep("Unhandled event type", { type: event.type });
    }

    return new Response("OK", { status: 200 });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logStep("ERROR in stripe-webhook", { message: errorMessage });
    return new Response("Internal Server Error", { status: 500 });
  }
});