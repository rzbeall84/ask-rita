import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.0';

const openAIApiKey = Deno.env.get('OPENAI_API_KEY');
const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { message } = await req.json();
    const authHeader = req.headers.get('Authorization');

    console.log('Received message:', message);

    if (!openAIApiKey) {
      throw new Error('OpenAI API key not configured');
    }

    if (!authHeader) {
      throw new Error('Authentication required');
    }

    // Initialize Supabase client
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Extract JWT token and get user
    const jwt = authHeader.replace('Bearer ', '');
    const { data: { user }, error: userError } = await supabase.auth.getUser(jwt);

    if (userError || !user) {
      console.error('Authentication error:', userError);
      throw new Error('Invalid authentication');
    }

    console.log('Authenticated user:', user.id);

    // Search user's uploaded documents for relevant content
    const { data: searchResults, error: searchError } = await supabase
      .rpc('search_user_documents', {
        p_user_id: user.id,
        p_search_query: message,
        p_limit: 3
      });

    if (searchError) {
      console.error('Error searching documents:', searchError);
      // If search fails, return fallback message
      return new Response(JSON.stringify({
        response: "I wasn't able to find that in your files. Please upload the missing document or check with your manager."
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log('Search results:', searchResults);

    // Check if we found relevant content
    if (!searchResults || searchResults.length === 0) {
      return new Response(JSON.stringify({
        response: "I wasn't able to find that in your files. Please upload the missing document or check with your manager."
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Build context from search results
    let documentContext = '';
    const sourceFiles = [];

    for (const result of searchResults) {
      documentContext += `\n\nFrom ${result.file_name} (${result.category_name} - ${result.folder_name}):\n${result.content_snippet}`;
      sourceFiles.push(`${result.file_name} (${result.category_name} - ${result.folder_name})`);
    }

    console.log('Built document context, length:', documentContext.length);

    // Use OpenAI with document context only
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openAIApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          {
            role: 'system',
            content: `You are Rita, an AI recruiting assistant for the transportation industry. 

CRITICAL INSTRUCTIONS:
- Answer recruiter questions STRICTLY using the organization's uploaded carrier, job, recruiter training, and driver qualification files provided in the context below.
- If the answer cannot be found in the provided document context, respond EXACTLY with: "I wasn't able to find that in your files. Please upload the missing document or check with your manager."
- NEVER use external knowledge or make up information not contained in the provided context.
- Always cite which document(s) you're referencing in your response.
- Keep responses conversational but professional.

Document Context:
${documentContext}`
          },
          {
            role: 'user',
            content: message
          }
        ],
        max_tokens: 1000,
        temperature: 0.3, // Lower temperature for more focused responses
      }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      console.error('OpenAI API error:', errorData);
      throw new Error(`OpenAI API error: ${response.status}`);
    }

    const data = await response.json();
    console.log('OpenAI response received');

    let aiMessage = data.choices[0].message.content;

    // Add source citation
    if (sourceFiles.length > 0) {
      aiMessage += `\n\n📄 Sources: ${sourceFiles.join(', ')}`;
    }

    return new Response(JSON.stringify({ response: aiMessage }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in rita-chat function:', error);
    
    // Return fallback message for any errors
    return new Response(JSON.stringify({ 
      response: "I wasn't able to find that in your files. Please upload the missing document or check with your manager."
    }), {
      status: error.message === 'Authentication required' || error.message === 'Invalid authentication' ? 401 : 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});